#!/bin/sh


###########################################################
# This script deploys a package for the applicataotions   #
#                             Reginaldo Costa, Feb 2012   #
###########################################################

function usage {
    POSSIBLE_APPLICATIONS="$*"
    cat <<EOF!!

     usage:
            deployPackage.sh <tar.gz package file> <destination directory>  [ <application list> | ALL ]

            Where
                   <tar.gz package file>     ::= /path../path../configtool.AAMMMDDHHMMSS.tar.gz
                   <destination directory>   ::= /path../path../path  (default is current directory: .)
                   <application list>  ::= ALL or any of the applications [$POSSIBLE_APPLICATIONS]

EOF!!

}

NOW=`/bin/date '+%y%m%d%H%M%S'`

NODENAME=`uname -n`
NODENAME=${NODENAME%%.*}
NODENAME=`echo "$NODENAME" | tr [:lower:] [:upper:]`
NODEPREFIX=${NODENAME%%[0-9]*[0-9]}
NODELETTER=${NODEPREFIX:$(expr ${#NODEPREFIX} - 1)}
ENVIRONMENT=$(echo "$NODELETTER" | awk 'BEGIN {e["P"]="Prod"; e["I"]="Int"; e["O"]="Mac"; e["D"]="Dev"; e["C"]="Cert"};{print e[$1]}')



if [ "$1" == "" ] ; then
    echo "**ERROR** you must provide tar.gz package file name"
    usage ""
    exit 2
fi
TAR_FILE=$1
shift
if [ ! -f $TAR_FILE ] ; then
    echo "**ERROR** file $TAR_FILE not found"
    usage ""
    exit 3
fi

APPLICATION_DIRECTORIES=$( tar -tzf $TAR_FILE | awk -F/ '\
        $0 ~ "Collector/src" && NF > 4 && index(apps,$4) == 0 { 
                apps=sprintf("%s %s", apps, $4);
        }
        END { print substr(apps,2); }   
') 
POSSIBLE_APPLICATIONS=$(echo "$APPLICATION_DIRECTORIES" | tr [:lower:] [:upper:])

if [ "$1" == "" ] ; then
    echo "**ERROR** you must provide target directory"
    usage "$POSSIBLE_APPLICATIONS"
    exit 4
fi
TARGET_DIR=$1
shift
if [ ! -d $TARGET_DIR ] ; then
    mkdir -p $TARGET_DIR
    echo "*Warning* Target directory $TARGET_DIR created"
    #usage "$POSSIBLE_APPLICATIONS"
    #exit 4
fi

# Applications list or ALL
if [ "$1" == "" ] ; then
    APPLICATIONS="$POSSIBLE_APPLICATIONS"
else
    REQ=`echo "$1" | tr [:lower:] [:upper:]`
    if [ "$REQ" == "ALL" ] ; then
        APPLICATIONS="$POSSIBLE_APPLICATIONS"
    else
        APPLICATIONS=`echo "$*" | tr [:lower:] [:upper:]`
    fi
fi

EXCL=""

for APP in $APPLICATION_DIRECTORIES
do
    FOUND=0
    APPU=$(echo "$APP" | tr [:lower:] [:upper:])
    for INCL in $APPLICATIONS ; do
        [ "$INCL" == "$APPU" ] && FOUND=1
    done
    [ $FOUND -eq 0 ] && EXCL="$EXCL $APP"
done


cat <<EOF!!
Time is $NOW
Available applications within $TAR_FILE are: $POSSIBLE_APPLICATIONS
Requested applications are: $APPLICATIONS
Excluded applications are: $EXCL
EOF!!

TAREXCL=""
if [ ! "$EXCL" == "" ] ; then
    for exclude in $EXCL ; do
         TAREXCL="$TAREXCL --exclude Collector/src/$exclude"
    done
fi
set -x
cd $TARGET_DIR
tar -xzf $TAR_FILE  $TAREXCL
cd -
set -

exit 0

