#!/bin/sh

set -x
set log=-Dlog4j.debug
export log2="-Deiapi.configuration=SabreConfigUtil.xml"
export log3="-Deiapi.configuration=eiapi-log4j-trans-summary-pubsub.xml"

LIB=.:./resources:./SabreConfigUtil.jar
LIB=$LIB:lib/ojdbc5.jar
LIB=$LIB:lib/eiapi-1.4.1.jar
LIB=$LIB:lib/eiapi-psappender-1.4.1-20110929.203010-1.jar
LIB=$LIB:lib/log4j-1.2.15.jar
LIB=$LIB:lib/tibjms-4.4.3.jar
LIB=$LIB:lib/jms-1.1.jar
echo $LIB


# --> doesn't work: java $log $log2  -classpath $LIB -jar SabreConfigUtil.jar listOracle -
#java $log $log2  -classpath $LIB com.sabre.config.ConfigMain listOracle -

# --> doesn't work: java $log $log2  -classpath $LIB -jar SabreConfigUtil.jar    publish REGI.COSTA SabreConfigUtil.xml
                    java $log $log3  -classpath $LIB com.sabre.config.ConfigMain publish REGI.COSTA SabreConfigUtil.xml

set -


