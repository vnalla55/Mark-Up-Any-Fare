#!/bin/sh

########################################################
# This script updates the nodeID on SabreConfigUtil.xml
# This is necessary while the eiapi doesn't publish the
# nodeID automatically.
#                         Reginaldo Costa, Feb 2012.
########################################################


NODENAME=`uname -n`
NODENAME=${NODENAME%%.*}
NODENAME=`echo "$NODENAME" | tr [:lower:] [:upper:]`
NODEPREFIX=${NODENAME%%[0-9]*[0-9]}
if [ "${JAVA_HOME}x" == "x" ] 
then
    JAR=jar
else
    JAR=$JAVA_HOME/bin/jar
fi
SEARCH=NODENODENODENODE
if [ ! -f SabreConfigUtil.jar ] ; then
    echo "SabreconfigUtil.jar not found @ current directory $PWD"
    exit 2
fi
OK=1
$JAR -tf SabreConfigUtil.jar | grep 'SabreConfigUtil.original.xml' > /dev/null
if [ "$?" == "0" ] ; then
    $JAR -xf SabreConfigUtil.jar SabreConfigUtil.original.xml
else
    $JAR -tf SabreConfigUtil.jar | grep 'SabreConfigUtil.xml' > /dev/null
    if [ "$?" == "0" ] ; then
        $JAR -xf SabreConfigUtil.jar  SabreConfigUtil.xml
        mv SabreConfigUtil.xml SabreConfigUtil.original.xml
    else
        echo "Error, neither SabreConfigUtil.xml or SabreConfigUtil.original.xml found on SabreConfigUtil.jar"
        OK=0
    fi       
fi
if [ $OK == 1 ] ; then
    sed "s/${SEARCH}/${NODENAME}/" SabreConfigUtil.original.xml > SabreConfigUtil.xml
    $JAR -uf SabreConfigUtil.jar  SabreConfigUtil.xml SabreConfigUtil.original.xml
fi


