#!/bin/sh

set -x
  javac -classpath SabreConfigUtil.jar -d . OracleConnection.java
  [ "$?" == "0" ] && jar -uf SabreConfigUtil.jar com/sabre/config/OracleConnection.class
set -


