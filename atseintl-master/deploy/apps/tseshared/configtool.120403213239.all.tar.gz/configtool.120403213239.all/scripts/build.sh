#!/bin/sh

NODENAME=`uname -n`
NODENAME=${NODENAME%%.*}
NODENAME=`echo "$NODENAME" | tr [:lower:] [:upper:]`
NODEPREFIX=${NODENAME%%[0-9]*[0-9]}
ENVIRONMENT=PROD
#[ "$NODEPREFIX"      == "CTOVM" ]      && ENVIRONMENT=DEV 
#[ "$NODENAME"        == "PRGNR08" ]    && ENVIRONMENT=DEV
[ "$NODENAME"        == "RELAMPAGO" ]  && ENVIRONMENT=DEV

CLEAN=NO
RECOMPILE=NO
PARAM=`echo "$1" | tr [:lower:] [:upper:]`
if [ "$PARAM" == "CLEAN" ] ; then
    CLEAN=YES
    RECOMPILE=NO
    shift
fi

PARAM=`echo "$1" | tr [:lower:] [:upper:]`
if [ "$PARAM" == "RECOMPILE" ] ; then
    RECOMPILE=YES
    CLEAN=NO
    shift
fi

PARAM=`echo "$1" | tr [:lower:] [:upper:]`
if [ "$PARAM" == "SOURCEDIR" ] ; then
    SOURCEDIR=$2
    CONFIGTOOLDIR=${SOURCEDIR}
    shift
    shift
else
    SOURCEDIR=~/svn.local
    [ -d ~/sabre/svn.local ] &&  SOURCEDIR=~/sabre/svn.local
    CONFIGTOOLDIR=${SOURCEDIR}/eam/configtool
fi

if [ ! -d $SOURCEDIR ] ; then
    echo "Local distribution directory not found: $SOURCEDIR"
    exit
fi

# This builds SabreConfigUtil 
JAVA_VERSION=$(\
     echo `java -version 2>&1` | awk '$2 == "version" {print $3}' | awk -F. '{print $2}'\
)
OJDBC=ojdbc${JAVA_VERSION}.jar

echo "*INFO* $0"
echo "*INFO* Options entered CLEAN=$CLEAN, RECOMPILE=$RECOMPILE, SOURCEDIR=$SOURCEDIR"
echo "*INFO* JAVA VERSION=$JAVA_VERSION ==> JDBC module is ${OJDBC}"
if [ ! -d $CONFIGTOOLDIR ] ; then
    echo "SabreConfigTool source directory not found: $CONFIGTOOLDIR"
    exit
fi

JARFILE=SabreConfigUtil

PROJ=${CONFIGTOOLDIR}/SabreConfigUtil # Source base dir
if [ "$1" == "" ] ; then
    DIST=${CONFIGTOOLDIR}/dist # Targets
else
    DIST=$1
fi

if [ ! "${DIST:0:1}" == "/" ] ; then
     DIST=${PWD}/${DIST}
fi

if [ ! -d $DIST ] ; then
     echo "Target Directory not found: $DIST"
     exit
fi

SRC=${DIST}/src
LIB=${DIST}/lib
SCRIPTS=${DIST}/scripts
CLASSES=${DIST}/classes

MANIFEST=/tmp/manifest_$$.txt

cat <<EOF!!!
----- VARIABLES -----
  ENVIRONMENT=$ENVIRONMENT
  JARFILE=$JARFILE
  MANIFEST=$MANIFEST
  CONFIGTOOLDIR=$CONFIGTOOLDIR
  SRC=$SRC
  LIB=$LIB
  SCRIPTS=$SCRIPTS
  CLASSES=$CLASSES

EOF!!!

if [ "$CLEAN" == "YES" ] ; then
    rm -rv $SRC $LIB $SCRIPTS $CLASSES
fi

[ ! -d $SRC/com/sabre/config ]     && mkdir -p $SRC/com/sabre/config
[ ! -d $LIB ]     && mkdir -p $LIB
[ ! -d $SCRIPTS ] && mkdir -p $SCRIPTS
[ ! -d $CLASSES ] && mkdir -p $CLASSES

if [ "$RECOMPILE" == "YES" ] ; then
     echo "*WARNING* Java source NOT copied because of RECOMPILE=YES"
else
    cp -vr $PROJ/src/com/sabre/config/*.java $SRC/com/sabre/config
    [ "$ENVIRONMENT" == "DEV" ] && cp -v  $PROJ/etc/OracleConnection.java $SRC/com/sabre/config
    cp -v  $SRC/com/sabre/config/OracleConnection.java $DIST/.
    cp -v  $PROJ/scripts/buildOracleConnection.sh $DIST/.
fi
cp -vr $PROJ/src/*.xml    $SRC
cp -vr $PROJ/lib/*.jar    $LIB
cp -vr $PROJ/src/*.xml    $CLASSES
cp -vr $PROJ/scripts/*.sh $SCRIPTS

CLASSPATH=.:lib/${OJDBC}
CLASS_PATH=". lib/${OJDBC}"
cd $LIB
for JAR in *.jar ; do
    PREFIX=$(echo $JAR | awk '{print substr($1,1,5)}')
    if [ ! "$PREFIX" == "ojdbc" ] ; then
        CLASSPATH=$CLASSPATH:lib/$JAR
        CLASS_PATH="$CLASS_PATH lib/$JAR"
    fi
done
cd -


cd $DIST
javac -classpath  $CLASSPATH -sourcepath $SRC -d $CLASSES  -verbose  $SRC/com/sabre/config/*.java
cd -

cd $CLASSES
cat > $MANIFEST <<EOF!!
Class-Path: $CLASS_PATH
Main-Class: com.sabre.config.ConfigMain
EOF!!
jar -cvfm ${DIST}/${JARFILE}.jar ${MANIFEST} *

cd -

#--- Set node if script is deployed --
cd $DIST
[ -x $SCRIPTS/setNode.sh ] && $SCRIPTS/setNode.sh
cd -


