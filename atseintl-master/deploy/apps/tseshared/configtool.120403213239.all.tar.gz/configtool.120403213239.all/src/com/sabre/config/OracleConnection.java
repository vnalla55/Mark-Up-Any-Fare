/******************************************************************************
 *                    Copyright (c) 2003-2012 - Sabre Inc.
 *                            All rights reserved.
 *
 * This software is the  confidential and  proprietary intellectual property of
 * Sabre Inc.  Any  unauthorized use,  reproduction,  preparation of derivative
 * works, performance, or display of this software  without the express written
 * permission  of  Sabre Inc.,  is  strictly  prohibited.  This  software is an
 * unpublished work of  Sabre Inc.  and is subject to  LIMITED DISTRIBUTION AND
 * RESTRICTED DISCLOSURE only.
 ******************************************************************************
 */

package com.sabre.config;

// DB imports
import java.sql.*;

/**
 *
 * @author James Renaud / Reginaldo Costa
 */
public class OracleConnection implements DataBaseConnection {

    private final boolean implemented = false;
    	
	public Connection get() {
		
	    if (!implemented) {
                return null;
            }
        
	Connection db = null;
	String userid="secret", password="secret";
	
	String url = "jdbc:oracle:thin:@"+
		"(description=(load_balance=on)(failover=on)"+ 
		  "(address_list="+
			"(address=(host=hpblade02-vip.dev.sabre.com)(protocol=tcp)(port=1521))"+
			"(address=(host=hpblade10-vip.dev.sabre.com)(protocol=tcp)(port=1521))"+
		   ")"+
		  "(connect_data="+
			"(service_name=cto11gR2dev)"+
			"(server=dedicated)"+
		  ")"+
		")";

		
//	String jdbcDriver = "oracle.jdbc.driver.OracleDriver";  // prior to oracle 9i
	String jdbcDriver = "oracle.jdbc.OracleDriver"; // oracle 9i and higher
	try {
		Class.forName(jdbcDriver); //Or any other driver
	}
	catch(Exception x){
		System.err.printf( "Unable to load the %s driver class!\n", jdbcDriver );
		System.err.println("Failed: Driver Error: " + x);
		return null;
	}	
	try {
            db = DriverManager.getConnection(url, userid, password);
        }
        catch(SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage());
	}

	return db;
}
    
} // end class
