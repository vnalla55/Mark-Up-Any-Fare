/******************************************************************************
 *                    Copyright (c) 2003-2012 - Sabre Inc.
 *                            All rights reserved.
 *
 * This software is the  confidential and  proprietary intellectual property of
 * Sabre Inc.  Any  unauthorized use,  reproduction,  preparation of derivative
 * works, performance, or display of this software  without the express written
 * permission  of  Sabre Inc.,  is  strictly  prohibited.  This  software is an
 * unpublished work of  Sabre Inc.  and is subject to  LIMITED DISTRIBUTION AND
 * RESTRICTED DISCLOSURE only.
 ******************************************************************************
 */

package com.sabre.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//import java.util.regex.PatternSyntaxException;

/**
 *
 * @author Reginaldo Costa
 */
public class ConfigMain {

    // Argument indexes
    private static int              actionp     = 0;    // Action parameter
    private static int              outputp     = 1;    // Output parameter
    private static int              identifiersp = 1;   // identifier XML TAG statement
    private static int              propertyp   = 1;    // Property parameter
    private static int              inputp      = 2;    // 1st of input file list
    
    private static final String     publishIt   = "publish";    // Action to pubsub output
    private static final String     printIt     = "print";      // Action to print properties
    private static final String     javaArgsIt  = "javaArgs";   // Action to print JVM parameters
    private static final String     getPropIt   = "getProp";    // Action to get a property
    private static final String     listOracleIt= "listOracle"; // Action to list Oracle Properties
    private static final String     nullProp    = "";           // what is returned on getProp of non existant 
    
    private static Charset          charset     = Charset.forName("ISO-8859-2");  // Charset  
    private static CharsetDecoder   decoder     = charset.newDecoder();           // decoder
    private static Pattern          xmlPattern  = Pattern.compile("^[\n]*<\\?xml"); // To validate XML files
    /**
    private static Pattern          linePattern = Pattern.compile(".*\r?\n");     // Pattern used to parse lines
    private static Pattern          pattern;                                      // To compile regexps
    **/

    private static Properties       props       = new Properties();               // Properties buffer
    private static PrintWriter      out         = new PrintWriter(System.out);

    
    /**
     * Compile the pattern from the command line
     * @param pat regular expression pattern
     */
    /**
    static void compile(String pat) {
        try {
            pattern = Pattern.compile(pat);
        } catch (PatternSyntaxException x) {
            System.err.println(x.getMessage());
            System.exit(1);
        }
    }
    **/

    /**
     * Maps files into memory properly load them
     * @param f Actual file
     * @throws java.io.IOException throws IOException upon i/o error
     */
    static void loadFile(File f) throws IOException {
        
        // Open the file and then get a channel from the stream
        FileInputStream fis = new FileInputStream(f);
        FileChannel     fc  = fis.getChannel();
        
        // Get the file's size, map it into memory, decode into buffer
        int sz = (int) fc.size();
        MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0, sz);
        CharBuffer cb = decoder.decode(bb);
        
        Matcher xmlm = xmlPattern.matcher(cb); // XML matcher
        if (xmlm.find()) {
            try {
                ConfigXMLLoader.load(props, cb.toString());
                /**************************************************************
                 * The following commented lines are to parse from file instead
                 * of the buffered area
                 * 
                FileInputStream inFile = new FileInputStream(f.getAbsolutePath());
                ConfigXMLLoader.load(props, inFile);
                 */

            } catch (javax.xml.parsers.ParserConfigurationException e) {
                System.err.println("javax.xml.parsers.ParserConfigurationException on " + f.getName());
            } catch (org.xml.sax.SAXException e) {
                System.err.println("org.xml.sax.SAXException on " + f.getName());
            } catch (IOException e) {
                System.err.println("IOException on XML propertiesFile " + f.getName() + ": " + e.getMessage());
            }
        }
        else
        {
            StringReader strRdr = new StringReader(cb.toString());
            props.load(strRdr);
            strRdr.close();
        }
        // Perform the load
        //grep(f, cb);
        
        
        // Close the channel and the stream
        fc.close();
    }
    
    /**
     * Main method
     * @param args The command line arguments. Should consist of output file and
     * the list of files which should be loaded and parsed.
     */
    
    
    /**
     * @param args the command line arguments
     */
    
    public static void usage() {
        System.err.println(
                  "Usage: java -classpath lib -jar SabreConfigUtil.jar <operation> <parameters>\n"
                + "\nThe <operations> are:\n\n"
                + "print     <output filename  -OR- \"-\" for stdout> <input file list separated by spaces>\n"
                + "publish   <identifier xml tag statement> <\"-\" for stdin> -OR- <input file list separated by spaces>\n"
                + "javaArgs  <output filename  -OR- \"-\" for stdout>\n"
                + "getProp   <property name> <input file list separated by spaces>\n"
                + "listOracle <property name> <output filename  -OR- \"-\" for stdout>\n"
                + "\n*** Examples ***\n"
                + "=> Prints all properties loaded from foo.properties and bar.xml to stdout:\n"
                + "     java -classpath lib -jar SabreConfigUtil.jar print - foo.properties bar.xml\n"
                + "=> Prints all properties loaded from foo.properties and bar.xml to /tmp/results.properties:\n"
                + "     java -classpath lib -jar SabreConfigUtil.jar print /tmp/results.properties foo.properties bar.xml\n"
                + "=> Publishes to pubsub all properties loaded /tmp/results.properties with dimensions specified\n"
                + "     java -classpath lib -jar SabreConfigUtil.jar publish '<dimensions ENVIRONMENT=\"stage\" APPLICATION=\"SSI\" />' /tmp/results.properties\n"
                + "=> Publishes to pubsub all properties loaded from stdin:\n"
                + "     cat /tmp/results.properties | java -classpath lib -jar SabreConfigUtil.jar publish -\n"
                + "=> Print parameters for JVM on stdout:\n"
                + "     java -classpath lib -jar SabreConfigUtil.jar javaParms -\n"
                + "=> Print parameters for JVM on stdout and store it on a shell variable:\n"
                + "     JAVAARGS=`java -classpath lib -jar SabreConfigUtil.jar javaParms -`\n"
                + "          -OR-\n"
                + "     JAVAARGS=$(java -classpath lib -jar SabreConfigUtil.jar javaParms -)\n"
                + "=> Print property \"myFooProperty\" value to stdout and store it on a shell variable:\n"
                + "     PROPERTYVAL=`java -classpath lib -jar SabreConfigUtil.jar getProp myFooProperty`\n"
                + "          -OR-\n"
                + "     PROPERTYVAL=$(java -classpath lib -jar SabreConfigUtil.jar getProp myFooProperty)\n"
                + "=> Print property \"myFooProperty\" value to stdout:\n"
                + "     java -classpath lib -jar SabreConfigUtil.jar getProp myFooProperty\n"
                + "\n"
                );
    } 
    
    public static void main(String[] args) throws FileNotFoundException {
        
        if (args.length < 1) {
            usage();
            return;
        }
        
        //PrintWriter out  = new PrintWriter(System.out);
        if (  !args[actionp].equalsIgnoreCase(publishIt) 
           && !args[actionp].equalsIgnoreCase(printIt)
           && !args[actionp].equalsIgnoreCase(javaArgsIt)
           && !args[actionp].equalsIgnoreCase(getPropIt)
           && !args[actionp].equalsIgnoreCase(listOracleIt)
           ) {
            System.err.println("Invalid action \"" + args[actionp] + "\": Must be one of "
                               +        publishIt  
                               + ", " + printIt
                               + ", " + javaArgsIt
                               + ", " + getPropIt
                               + ", " + listOracleIt
                              );
            return;
            
        }
        if (args[actionp].equalsIgnoreCase(printIt) || args[actionp].equalsIgnoreCase(javaArgsIt)) {
            if (!args[outputp].equalsIgnoreCase("-")) {
                File o = new File(args[outputp]);
                try {
                    if (!o.createNewFile()) {
                        System.err.println("File " + args[outputp] + " is already there");
                        return;
                    }
                } catch (IOException x) {
                    System.err.println(o + ": " + x);
                }

                out = new PrintWriter(o);
            }
        }
        

        if (args.length < 2) {
            usage();
            out.close();
            return;
        }
        
        //if (args[actionp].contentEquals(printIt)) {
        //    out.println("# Properties file generated by SabreConfigUtil");
        //}

        // Traverse args from last to first to prevail the first ones
        for (int i = args.length - 1; i >= inputp; i--) {
            File f = new File(args[i].equals("-") ? "stdin" : args[i]);
            //if (args[actionp].contentEquals(printIt)) {
            //    out.println("# From file: " + f.getAbsolutePath());
            //}
            try {
                loadFile(f);
            } catch (IOException x) {
                System.err.println(f + ": " + x);
            }
        }
        
        // Output all properites loaded
        if (args[actionp].contentEquals(printIt)) {
            for (Object propertyObj:props.keySet()) {
                  String property = (String) propertyObj;
                  out.printf("%s=%s\n", property, props.getProperty(property));
            }
        }

        // Output one property from the loaded ones
        if (args[actionp].contentEquals(getPropIt)) {
            String property = args[propertyp];
            out.printf("%s\n", props.containsKey(property) ? props.getProperty(property) : nullProp);
        }
        
        // Print Java Arguments
        if (args[actionp].contentEquals(javaArgsIt)) {
            RuntimeMXBean RuntimemxBean = ManagementFactory.getRuntimeMXBean();
            List<String> arguments = RuntimemxBean.getInputArguments();

            int c = 0;
            for (String argument:arguments) {
                System.out.printf("Java.arg.%d=%s\n", c++, argument); 
            }
            
            //final String javaParms =  arguments.toString();
            //out.printf("%s\n", javaParms.substring(1,javaParms.length()-1));
        }
        
        // Print Oracle Properites
        if (args[actionp].contentEquals(listOracleIt)) {
            String[] nullParm = null;
            try {
            ListOracleConfig.main(nullParm);
            } catch(Exception x){
                System.err.println("Failed on ListOracleConfig.main call " + x);
            }	
    
        }
        
        
        out.close();
        if (args[actionp].equalsIgnoreCase(publishIt)) {
            PubConfigData.publish(args[identifiersp], props);
        }
        
    }
}
