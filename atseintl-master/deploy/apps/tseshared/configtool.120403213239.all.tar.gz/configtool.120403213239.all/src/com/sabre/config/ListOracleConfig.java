/******************************************************************************
 *                    Copyright (c) 2003-2012 - Sabre Inc.
 *                            All rights reserved.
 *
 * This software is the  confidential and  proprietary intellectual property of
 * Sabre Inc.  Any  unauthorized use,  reproduction,  preparation of derivative
 * works, performance, or display of this software  without the express written
 * permission  of  Sabre Inc.,  is  strictly  prohibited.  This  software is an
 * unpublished work of  Sabre Inc.  and is subject to  LIMITED DISTRIBUTION AND
 * RESTRICTED DISCLOSURE only.
 ******************************************************************************
 */

package com.sabre.config;

// Make sure to do the following before running this java
// export CLASSPATH=.:/home/prgnusr/svn.devnet/eam/configtool/java/lib/ojdbc5.jar

// DB imports
import java.sql.*;

/**
 *
 * @author James Renaud / Reginaldo Costa
 */

interface DataBaseConnection {
    public String baseclass = "DataBaseConnection";
    public Connection get();
}

public class ListOracleConfig {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        DataBaseConnection DBConn = new OracleConnection();
        Connection db = DBConn.get();
        if (db != null) {
            ResultSet rset;
    	    Statement stmt = db.createStatement();
            // get the oracle version
            rset = stmt.executeQuery("select banner from v$version");
       	    System.out.printf("DB.Oracle.Version=%s\n",    rset.next() ? rset.getString(1) : "Not Available");
            // Get the sga_max_size    		
            rset = stmt.executeQuery("select name, value/1024/1024  from v$parameter where name = 'sga_max_size'");
            System.out.printf("DB.Oracle.Sga=%s\n",       rset.next() ? rset.getString(2) : "Not Available");
            // Get the max cursors    		
            rset = stmt.executeQuery("select name, value from v$parameter where name = 'open_cursors'");
            System.out.printf("DB.Oracle.Cursors=%s\n",   rset.next() ? rset.getString(2) : "Not Available");
            // Get the max processes    		
            rset = stmt.executeQuery("select name, value from v$parameter where name = 'processes'");
            System.out.printf("DB.Oracle.Processes=%s\n", rset.next() ? rset.getString(2) : "Not Available");

            rset.close();
            stmt.close();
            DatabaseMetaData meta = db.getMetaData();
            System.out.printf("DB.Oracle.DriverName=%s\n",    meta != null ? meta.getDriverName()    : "Not Available");
            System.out.printf("DB.Oracle.DriverVersion=%s\n", meta != null ? meta.getDriverVersion() : "Not Available");
            System.out.printf("DB.Oracle.URL=%s\n",           meta != null ? meta.getURL()           : "Not Available");
            db.close();		
        }
        else 
        {
           System.out.println( "DB.Oracle.Version=Not Implemented\n"
                             + "DB.Oracle.Sga=Not Implemented\n"
                             + "DB.Oracle.Cursors=Not Implemented\n"
                             + "DB.Oracle.Processes=Not Implemented\n"
                             + "DB.Oracle.DriverName=Not Implemented\n"
                             + "DB.Oracle.DriverVersion=Not Implemented\n"
                             + "DB.Oracle.URL=Not Implemented"
                             );
        }	

    }

}

