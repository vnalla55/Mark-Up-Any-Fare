/*
 * SabreConfigUtil constants
 * 
 */
package com.sabre.config;

/**
 *
 * @author Reginaldo Costa
 */
public class Const {
    
    // For PubConfigData
    static final String VERSIONVALUE           = "1.0";
    static final String MQSERVICENAME          = "sabreConfigSender";
    static final String MOMCONFIGPREFIX        = "momconfig";
    static final String MOMCONFIGXMLFILE       = "mom.config.xml.file";
    static final String RECORDTYPEITEM         = "RECORDTYPE"    .toUpperCase(); 
    static final String RECORDTYPEBASIC        = "CFGBASEDATA"   .toUpperCase();

    public static final String VERSION         = "VERSION"       .toUpperCase();
    public static final String COMPLEX         = "COMPLEX"       .toUpperCase();
    public static final String NODE            = "NODE"          .toUpperCase();
    public static final String APPLICATION     = "APPLICATION"   .toUpperCase();
    public static final String ENVIRONMENT     = "ENVIRONMENT"   .toUpperCase();
    public static final String IDXMLTAGSTMT    = "IDXMLTAGSTMT"  .toUpperCase();
    public static final String GENTIME         = "GENTIME"       .toUpperCase();
    public static final String CFGITEMSCOUNT   = "CFGITEMSCOUNT" .toUpperCase();
    public static final String LOADID          = "LOADID"        .toUpperCase();
    public static final String PACKAGE         = "PACKAGE"       .toUpperCase();
    public static final String SCRIPT          = "SCRIPT"        .toUpperCase();    
    public static final String UNKNOWN         = "UNKNOWN"       .toUpperCase();
    public static final String VAULT           = "VAULT"         .toUpperCase();
    public static final String VAULT_YES       = "Y"             .toUpperCase();
    public static final String VAULT_NO        = "N"             .toUpperCase();
    public static final String VAULTDEFAULT    = VAULT_NO        .toUpperCase();
    
    static final String dimensionsTag = "dimensions";
    static final String dimensionsDefault =  "<" + dimensionsTag
                                           + " " + COMPLEX     + "=\"" + UNKNOWN + "\""
                                           + " " + NODE        + "=\"" + UNKNOWN + "\""
                                           + " " + ENVIRONMENT + "=\"" + UNKNOWN + "\""
                                           + " " + LOADID      + "=\"" + UNKNOWN + "\""
                                           + " " + PACKAGE     + "=\"" + UNKNOWN + "\""
                                           + " " + SCRIPT      + "=\"" + UNKNOWN + "\""
                                           + " " + "/>"
                                           ;
    
    //this prevents even the native class from 
    //calling this
    private Const() { throw new AssertionError(); }
                        
}
