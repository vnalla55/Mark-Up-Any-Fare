/******************************************************************************
 *                    Copyright (c) 2003-2012 - Sabre Inc.
 *                            All rights reserved.
 *
 * This software is the  confidential and  proprietary intellectual property of
 * Sabre Inc.  Any  unauthorized use,  reproduction,  preparation of derivative
 * works, performance, or display of this software  without the express written
 * permission  of  Sabre Inc.,  is  strictly  prohibited.  This  software is an
 * unpublished work of  Sabre Inc.  and is subject to  LIMITED DISTRIBUTION AND
 * RESTRICTED DISCLOSURE only.
 ******************************************************************************
 */

package com.sabre.config;


import com.sabre.messaging.config.MOMConstants;
import com.sabre.messaging.service.MessageContext;
import com.sabre.messaging.service.MessageContextFactory;
import com.sabre.messaging.service.Service;
import com.sabre.messaging.service.ServiceManager;
import com.sabre.messaging.service.alert.Alert;
import com.sabre.messaging.service.alert.AlertListener;
import com.sabre.messaging.util.MessagingException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Reginaldo Costa
 */
public class PubConfigData {
   
    static {
        System.setProperty("LDAPConfig", "false");
        //System.setProperty(Const.MOMCONFIGXMLFILE, Const.MOMCONFIGPREFIX + ".xml");
    }
    
    /**
     * @param args the identifiers XML tag statement
     */

/*****************************************************************************
 *     constructor
 *****************************************************************************/
   private PubConfigData() {
        throw new UnsupportedOperationException("Please use the static publish(idstmt,prop) method rather than the constructor.");
   }

/*****************************************************************************
 *     main
 *****************************************************************************/
   public static void publish(String dimensionsString, Properties props) {
    
        try {
            momLogger(dimensionsString, props);
        } 
        catch (Exception e) {
            System.err.print("Exception caught on PubConfigData.publish");
            System.exit(0x2);
        }

    }

   public static void momLogger(String dimensionsStmt, Properties props)
   {
       Service service = null;
       Properties idProps = new Properties();   // identifiers propeties buffer
       parseXMLTAG(idProps,Const.dimensionsDefault.toUpperCase()); // Put defaults first
       
       try {
    	   System.setProperty(MOMConstants.DISABLE_DISCRETE_EVENT, "true");
    	   System.setProperty(MOMConstants.DISABLE_METRICS, "true");
    	   
    	   MessageContext message = MessageContextFactory.createMessageContext();
           
           // Automatic identifiers.
           String node = getHostName()       .toUpperCase();
           String envr = getEnvironment(node).toUpperCase();
    	   idProps.setProperty( Const.VERSION,        Const.VERSIONVALUE);
    	   idProps.setProperty( Const.NODE,           node);
           idProps.setProperty( Const.ENVIRONMENT,    envr);
    	   idProps.setProperty( Const.GENTIME,        timestampNow());
           idProps.setProperty( Const.CFGITEMSCOUNT,  String.valueOf(props.keySet().size()));
    	   idProps.setProperty( Const.IDXMLTAGSTMT,   dimensionsStmt);
           idProps.setProperty( Const.RECORDTYPEITEM, Const.RECORDTYPEBASIC);
           
           // Parse the ones passed by parameter:
           if (dimensionsStmt.toUpperCase().startsWith("<" + Const.dimensionsTag.toUpperCase())) {
               parseXMLTAG(idProps,dimensionsStmt.toUpperCase());
           }
           
           // Put resulting identifiers properties into message header (User properties)
           for (Object ID:idProps.keySet()) {
               String elementID = (String) ID.toString(); // old: .substring(Const.dimensionsTag.length() + 1);
               message.setUserProperty(elementID, idProps.getProperty((String) ID));
           }
    	   
           // Put whole props into message payload
           ByteArrayOutputStream bstr = new ByteArrayOutputStream();
    	   props.storeToXML(bstr, dimensionsStmt, "UTF-8"); // Dump props into bstr; 2nd parameter is a comment
    	   message.setBytes(bstr.toByteArray());
           
           String environment = idProps.getProperty(Const.ENVIRONMENT, envr);
           String vault       = idProps.getProperty(Const.VAULT, Const.VAULTDEFAULT);
           String vaultFlag   = (vault.toUpperCase().startsWith(Const.VAULT_YES) ? "V" : "").toLowerCase();
           if (System.getProperty( Const.MOMCONFIGXMLFILE) == null ) {
               System.setProperty( Const.MOMCONFIGXMLFILE
                                 , Const.MOMCONFIGPREFIX.toLowerCase()
                                 + "_" + environment.toLowerCase() + vaultFlag
                                 + "_" + Const.MQSERVICENAME.toLowerCase()
                                 + ".xml"
                                 );
           }
           //System.err.printf( Const.MOMCONFIGXMLFILE + ": %s\n"
           //                 , System.getProperty(Const.MOMCONFIGXMLFILE) == null ? "NULL" 
           //                 : System.getProperty(Const.MOMCONFIGXMLFILE)
           //                 );
    	   
           ServiceManager mgr = ServiceManager.getInstance();
           MyAlertListener momAlertListener = new MyAlertListener();
           mgr.setAlertListener(momAlertListener);

           service = mgr.getSenderService(Const.MQSERVICENAME);
           service.start();
    	   
           service.send(message, 5000);
           bstr.close();
    	   
       }
       catch(Exception ex) 
       {
    	   ex.printStackTrace();
           System.err.println("Configuration Logger Exception:" + ex);
           System.exit(9);
       }finally{
            try {
                // Assuming only one mom service is used.
                if(service != null)
                    ServiceManager.close();
            } catch (MessagingException e) {
                    e.printStackTrace();
            }
       }
       
   }

    public static String getHostName() {
        StringBuilder hostName = new StringBuilder("");
        try {
            java.net.InetAddress localMachine = java.net.InetAddress.getLocalHost();
            hostName.append((localMachine.getHostName().toUpperCase().split("\\."))[0]);
        }
        catch (java.net.UnknownHostException uhe) {
            hostName.append(Const.UNKNOWN);
            //System.err.println( "Got exception from java.net.InetAddress.getLocalHost()"
            //                  + uhe.toString()
            //                  );
        }
        
        //while (hostName.length() < 16) hostName.append(" ");
        return hostName.toString();
    }
    
    public static String timestampNow() {
        DateParser dp = new DateParser();
        String genDate = dp.format(new Date());
        return genDate;
    }
    
    public static void parseXMLTAG(Properties prop, String XMLTAGStatement) {
        String startDepthSaved = System.getProperty("ConfigXMLLoader.startDepth");
        if (startDepthSaved == null)
            startDepthSaved = "0";
        System.setProperty("ConfigXMLLoader.startDepth","1");
        try {
            ConfigXMLLoader.load(prop, XMLTAGStatement);
        } catch (javax.xml.parsers.ParserConfigurationException e) {
            System.err.println("javax.xml.parsers.ParserConfigurationException on " + XMLTAGStatement);
        } catch (org.xml.sax.SAXException e) {
            System.err.println("org.xml.sax.SAXException on " + XMLTAGStatement);
        } catch (IOException e) {
            System.err.println("IOException on XML propertiesFile " + XMLTAGStatement + ": " + e.getMessage());
        }
        System.setProperty("ConfigXMLLoader.startDepth",startDepthSaved);
        
    }
    
    public static String getEnvironment(String nodeName) {
        
        final Pattern p = Pattern.compile("[0-9]+?");
        final Matcher m = p.matcher("");
        final String[] environments = { "PCSIDO" // P=Prod, C=Cert, S=Stage, I=Int, D=Dev
                                      , Const.UNKNOWN   // must be the first
                                      , "PROD"
                                      , "CERT"
                                      , "STAGE"
                                      , "INT"
                                      , "DEV"
                                      , "MAC"
                                      };
        String NODE = nodeName.toUpperCase();
        m.reset(NODE);
        int i;
        if (m.find())
            i = m.start(0) - 1;        // last letter before numbers
        else
            i = nodeName.length() - 1; // last letter of node (no numbers found)
        
        char letter = NODE.charAt(i);
        int k = environments[0].indexOf(letter) + 2;
        String ENV = environments[k];
        
        return ENV;
    }
    //-----------------------------------------------------------------------------------
    public static class MyAlertListener implements AlertListener {
        @Override
        public void onAlert(Alert a) {
            switch( a.getMomReasonCode() )
            {
                //Queue "put" related alerts
                case MessagingException.S_SEND_FAILED_QUEUE_FULL:
                    System.err.println("ALERT: S_SEND_FAILED_QUEUE_FULL");
                break;

                case MessagingException.S_SEND_FAILED_PUT_INHIBIT:
                    System.err.println("ALERT: S_SEND_FAILED_PUT_INHIBIT");
                break;

                //Connection related alerts
                case MessagingException.S_CONNECTION_FAILED:
                    System.err.println("ALERT: S_CONNECTION_FAILED");
                break;

                case MessagingException.S_CONNECTION_SUCCEEDED:
                    System.out.println("ALERT: S_CONNECTION_SUCCEEDED");
                break;

                case MessagingException.S_CONNECTION_STATUS_ALLDOWN:
                    System.err.println("ALERT: S_CONNECTION_STATUS_ALLDOWN");
                break;

                case MessagingException.S_CONNECTION_STATUS_SOMEDOWN:
                    System.out.println("ALERT: S_CONNECTION_STATUS_SOMEDOWN");
                break;

                case MessagingException.S_CONNECTION_STATUS_ALLUP:
                    System.out.println("ALERT: S_CONNECTION_STATUS_ALLUP");
                break;

                //Thread pool related alerts
                case MessagingException.S_SEND_POOL_OVER_THRESHOLD:
                    System.err.println("ALERT: S_SEND_POOL_OVER_THRESHOLD");
                break;

                case MessagingException.S_RECEIVE_POOL_OVER_THRESHOLD:
                    System.err.println("ALERT: S_RECEIVE_POOL_OVER_THRESHOLD");
                break;

            } // end switch
        } // end onAlert
    } // end MyAlertListener    
}
