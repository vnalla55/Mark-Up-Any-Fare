/******************************************************************************
 *                    Copyright (c) 2003-2012 - Sabre Inc.
 *                            All rights reserved.
 *
 * This software is the  confidential and  proprietary intellectual property of
 * Sabre Inc.  Any  unauthorized use,  reproduction,  preparation of derivative
 * works, performance, or display of this software  without the express written
 * permission  of  Sabre Inc.,  is  strictly  prohibited.  This  software is an
 * unpublished work of  Sabre Inc.  and is subject to  LIMITED DISTRIBUTION AND
 * RESTRICTED DISCLOSURE only.
 ******************************************************************************
 */
package com.sabre.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Properties;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

// Author: Ron Smith (Original version)
// Author: Reginaldo Costa (Extended version)

/**
 * Load an XML configuration file.
 */
public class ConfigXMLLoader {
    
    private static final boolean useNameSpaceOnly = false;

    /**
     * Resolve entities.
     */
    private static final EntityResolver resolver = new EntityResolver() {
        @Override
        public InputSource resolveEntity(String publicID, String systemID) throws SAXException {
            return new InputSource(new StringReader(""));
        }
    };

    /**
     * Pure static class, don't allow instances.
     */
    private ConfigXMLLoader() {
        throw new UnsupportedOperationException("Please use the static load() method rather than the constructor.");
    }

    /**
     * load <param>; tags from an XML log4j configuration file.
     *
     * @param props where to place the values read
     * @param propStream where to read the XML configuration
     */
    public static void load(Properties props, InputStream propStream) throws SAXException, ParserConfigurationException, IOException {
        XMLReader reader = XMLReaderFactory.createXMLReader();
        reader.setEntityResolver(resolver);
        reader.setContentHandler(new ConfigHandler(props));
        reader.parse(new InputSource(propStream));
    }

    // The following load method is part of the extended version
    public static void load(Properties props, String propString) throws SAXException, ParserConfigurationException, IOException {
        XMLReader reader = XMLReaderFactory.createXMLReader();
        reader.setEntityResolver(resolver);
        reader.setContentHandler(new ConfigHandler(props));
        reader.parse(new InputSource(new StringReader(propString)));
    }

    /**
     * The XML configuration handler.
     */
    private static final class ConfigHandler extends DefaultHandler {

        private int depth;
        private String path;
        private final Properties props;
        
        String startDepthStr = System.getProperty("ConfigXMLLoader.startDepth","0");
        int    startDepth    = Integer.parseInt(startDepthStr);
        StringBuffer accumulator = new StringBuffer();  // Extended: Accumulate parsed text
        String[] xmlNameTagList = System.getProperty("ConfigXMLLoader.xmlNameTags","name,id").split(",", 0);
 
        /**
         * Construct the XML configuration handler.
         *
         * @param props where to place the values read
         */
        private ConfigHandler(Properties props) {
            this.depth = 0;
            this.path = "";
            this.props = props;
        }
        
        // The following characters method is part of the extended version
        @Override
        public void characters(char[] buffer, int start, int length) {
            accumulator.append(buffer, start, length);
        }

        /**
         * An element (or tag) is starting.
         *
         * @param namespace the namespace
         * @param localName the local name
         * @param tagName the tag name
         * @param attributes the attributes
         * @throws SAXException
         */
        @Override
        public void startElement(String namespace, String localName, String tagName, Attributes attributes)
            throws SAXException {
            
            accumulator.setLength(0);  // Reset accumulator

            if (0 != path.length()) {
                path += '.';
            }

            // Place the param items in the properties list.
            if (tagName.equals("param")) {
                final String key = attributes.getValue("name").trim();
                final String value = attributes.getValue("value").trim();

                if ((null == key) || key.isEmpty()) {
                    System.err.println("<param> has an empty or null name attribute");
                } else if (null == value) {
                    System.err.println("<param name=\"" + key + "\"> has a null value attribute");
                } else {
                    if (depth <= 1) { // params at the top are just named as themselves.
                        props.setProperty(key, value);
                    } else {          // params nested within use the path.
                        props.setProperty(path + key, value);
                    }
                }
            } else {
                if (depth >= startDepth) {
                    // Use just the namespace if there is one.
                    int colon = useNameSpaceOnly ? tagName.indexOf(':') : -1;
                    if (-1 == colon) {
                        path += tagName;
                    } else {
                        path += tagName.substring(0, colon);
                    }
                }

                // Include the name attribute in the path if there is one.
                for (String xmlNameTag:xmlNameTagList) {
                    String aName = attributes.getValue(xmlNameTag);
                    if (null != aName) {
                        path += '.' + aName;
                    }
                }

                // When there is a class attribute, make a property assignment.
                String aClass = attributes.getValue("class");
                if (null != aClass) {
                    props.setProperty(path, aClass);
                }

                // Include other attributes, not part of properties file schema
                for (int i=0; i < attributes.getLength(); i++) {
                    String propName  = path + ((0 != path.length()) ? "." : "") + attributes.getQName(i);
                    String propValue = attributes.getValue(i);
                    props.setProperty(propName, propValue);
                }
            }

            depth++;
        }

        /**
         * An element (or tag) is ending.
         *
         * @param namespace the namespace
         * @param localName the local name
         * @param tagName the tag name
         * @throws SAXException
         */
        // The following endElement method was extended
        @Override
        public void endElement(String namespace, String localName, String tagName) throws SAXException {
            String tagValue = accumulator.toString().trim();
            if (tagValue.length() > 0) {
                props.setProperty(path, tagValue);
                accumulator.setLength(0);
            } else {
                accumulator.setLength(0);
                tagValue = "";
                for (Object propertyObj:props.keySet()) {
                    String property = (String) propertyObj;
                    for (String xmlNameTag:xmlNameTagList) {
                        if (property.startsWith(xmlNameTag) && (property.length() > path.length())) {
                            accumulator.append("_").append(props.getProperty(property));
                        }
                    }
                }
                if (accumulator.length() > 0) {
                    tagValue = accumulator.toString().substring(1).trim();
                    accumulator.setLength(0);
                    props.setProperty(path, tagValue);
                }
            }
            depth--;
            if ("param".equals(tagName)) {
                tagName = ""; // params are not included in the path.
            }
            int colon = useNameSpaceOnly ? tagName.indexOf(':') : -1;
            String tagInPath = tagName;
            if (-1 != colon) {
                tagInPath = tagInPath.substring(0, colon);
            }
            String lastPath = path;
            int index = path.lastIndexOf('.' + tagInPath);
            if (-1 == index ) {
                path = "";
            } else {
                path = path.substring(0, index);
            }
            // Include the tag in the path if within xmlNameTagList
            for (String xmlNameTag:xmlNameTagList) {
                if (xmlNameTag.equals(lastPath)) {
                    path += '.' + tagValue;
                }
            }
                
        }
    }
}

