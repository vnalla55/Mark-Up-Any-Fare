/**
 *
 * @author sg0549743 -- Reginaldo Costa
 * This parses an input date into local output date.
 * dateFormats vector determines the acceptable input date formats
 * dateOut determines the format of date on output
 */
package com.sabre.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;


/**
 *
 * @author regi
 */
public class DateParser {
    
        //private static final int regexOptions = Pattern.CASE_INSENSITIVE;
        private SimpleDateFormat dateOut = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss.S");

        private SimpleDateFormat[] dateFormats = new SimpleDateFormat[] {
            new SimpleDateFormat ("yyyy-MM-dd'T'HH:mm:ss.S z"), // for <date>
            new SimpleDateFormat ("yyyy-MM-dd'T'HH:mm:ss.S"),   // for <date>
            new SimpleDateFormat ("yyyyMMdd':'HHmmssS")         // for <time>
        };

        public String format (String inDate)
        {
            Date parsedDate = null;
            String cleanDate = null;
            if ( inDate.endsWith( "Z" ) ) {
                cleanDate = inDate.substring( 0, inDate.length() - 1) + "GMT-00:00";
            } else {
                if ( "-".equals(inDate.substring(4, 5)) ) {
                    int tzx = inDate.length() - 6;
                    cleanDate = inDate.substring(0, tzx) + " GMT" + inDate.substring(tzx);
                } else {
                    cleanDate = inDate;
                }
            }

            for(SimpleDateFormat sdf : dateFormats) {
                try {
                    parsedDate = sdf.parse(cleanDate);
                    //+System.err.println( "sdf " + sdf.toPattern() + ": Date Parsed OK: " + cleanDate );
                    break;
                }
                catch (ParseException ex) {
                    System.err.println( "sdf " + sdf.toPattern() + ": Date Parse Error: " + ex.getMessage() );
                }
            }

            try {
               return dateOut.format(parsedDate);
            }
            catch (NullPointerException ex)
            {
                System.err.println( "dateOut null pointer Date Format Error: " + ex.getMessage()
                             + ", inDate="          + inDate
                             + ", cleanDate="       + cleanDate
                             );
                return "";
            }

        }; // end format for String

        public String format (Date inDate)
        {
            try {
                return dateOut.format(inDate);
            } catch (NullPointerException ex) {
                System.err.println( "Date Format Error: " + ex.getMessage()
                                 + ", inDate="       + inDate
                             );
                return "";
            }
        } // end format for date

}
