#!/bin/sh

# This builds the collection scripts 
#
# build.sh [CLEAN] [SOURCEDIR <source directory>] TARGET_DIR APP_LIST
# APP_LIST = list of apps eac separated by a space (e.g., "t2tkt t2asr")
#

set -x

PROJNAME=Collector

#--- VARIABLES FOR INPUT PARAMETERS ----
NODENAME=`uname -n`
NODENAME=${NODENAME%%.*}
NODENAME=`echo "$NODENAME" | tr [:lower:] [:upper:]`
NODEPREFIX=${NODENAME%%[0-9]*[0-9]}
ENVIRONMENT=PROD
[ "$NODEPREFIX"      == "CTOVM" ]      && ENVIRONMENT=DEV 
[ "$NODENAME"        == "RELAMPAGO" ]  && ENVIRONMENT=DEV
[ "$NODENAME"        == "PRGNR08" ]    && ENVIRONMENT=DEV

CLEAN=NO
RECOMPILE=NO  # In case we have something compiled in the future
APP_LIST=
PARAM=`echo "$1" | tr [:lower:] [:upper:]`
if [ "$PARAM" == "CLEAN" ] ; then
    CLEAN=YES
    RECOMPILE=NO
    shift
fi

PARAM=`echo "$1" | tr [:lower:] [:upper:]`
if [ "$PARAM" == "RECOMPILE" ] ; then
    RECOMPILE=YES
    CLEAN=NO
    shift
fi

PARAM=`echo "$1" | tr [:lower:] [:upper:]`
if [ "$PARAM" == "SOURCEDIR" ] ; then
    SOURCEDIR=$2
    CONFIGTOOLDIR=${SOURCEDIR}
    shift
    shift
else
    SOURCEDIR=~/svn.local
    [ -d ~/sabre/svn.local ] &&  SOURCEDIR=~/sabre/svn.local
    CONFIGTOOLDIR=${SOURCEDIR}/eam/configtool
fi

if [ ! -d $SOURCEDIR ] ; then
    echo "Local distribution directory not found: $SOURCEDIR"
    exit
fi

if [ "$1" == "" ] ; then
    echo "Target Directory not specified"
    exit
else
    DIST=$1
    shift
fi
if [ ! "${DIST:0:1}" == "/" ] ; then                                                                                               
    DIST=${PWD}/${DIST}                                                                                                           
fi
PROJDIST=$DIST/$PROJNAME

PARAM=`echo "$1" | tr [:lower:] [:upper:]`
if [ "$PARAM" == "ALL" ] ; then
     APP_LIST=ALL
else
     APP_LIST="$@"
fi

if [ "$APP_LIST" == "" ] ; then
   echo "APP not specified"
   exit
fi

if [ ! -d $CONFIGTOOLDIR ] ; then
    echo "SabreConfigTool source directory not found: $CONFIGTOOLDIR"
    exit
fi

PROJ=${CONFIGTOOLDIR}/$PROJNAME # Source base dir

if [ "$CLEAN" == "YES" ] ; then
    rm -rvf $PROJDIST
fi

SCRIPTS=$PROJDIST/scripts
SRC=$PROJDIST/src

[ ! -d $SCRIPTS ]     && mkdir -p $SCRIPTS
[ ! -d $SRC ]         && mkdir -p $SRC

# copy scripts in the main script directory
cp -v $PROJ/scripts/* $SCRIPTS

# copy source in the main src directory
if [ "$APP_LIST" == "ALL" ] ; then
    cp -vr $PROJ/src/* $SRC
else
    cp -v $PROJ/src/* $SRC

    # copy the src in the app directories as requested
    for APPSUBDIR in $APP_LIST
    do
        if [ ! -d $PROJ/src/$APPSUBDIR ] ; then
            echo "$APPSUBDIR in error, directory $PROJ/src/$APPSUBDIR not found"
            exit 1
        fi
        [ ! -d $SRC/$APPSUBDIR ] && mkdir -p $SRC/$APPSUBDIR
        cp -vr $PROJ/src/$APPSUBDIR/* $SRC/$APPSUBDIR
    done
fi

set -

