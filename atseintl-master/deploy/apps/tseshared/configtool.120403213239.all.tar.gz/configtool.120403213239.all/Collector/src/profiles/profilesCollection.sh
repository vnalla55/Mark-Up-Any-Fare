#!/bin/bash

# profilesCollection.sh - collect config items for profiles.

echo running $0 $1
CONFIG_TOOL=$(readlink -f `dirname ${0}`/../../..)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)


source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 

###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###

unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getJBossVersion
getJBossVersion () {
#pashlc501_PPPAS-CERT1.sh
    FN=/sabre/ppp/$(echo $APPNAME | tr '[:upper:]' '[:lower:]')/confs/$(echo $NODE | tr '[:upper:]' '[:lower:]')_$INSTANCE.sh
    if [ "$ENV" = "Int" ] || [ "$ENV" = "Cert" ]
    then
        FN=/sabre/$(echo $APPNAME | tr '[:upper:]' '[:lower:]')/confs/$(echo $NODE | tr '[:upper:]' '[:lower:]')_$INSTANCE.sh
    fi
    echo $(grep '^JBOSS_HOME=' $FN | sed -e "s/.*-\([0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\).*/\1/")
}

unset -f getCamelVersion
getCamelVersion () {
    echo "Not Implemented"
}

unset -f getPools
getPools () {
    OUT=/tmp/getpools.$$.txt
    XML="/tmp/${SCRIPT%.*}.$$.header.xml"
    XML2="/tmp/${SCRIPT%.*}.$$.oracle-ds.xml"
    echo '<?xml version="1.0" encoding="UTF-8"?>' > $XML
    cat $XML $APPLDIR/deploy/pppas-oracle-ds.xml > $XML2
    $JAVA_BIN/java -DConfigXMLLoader.xmlNameTags="name,id,datasources.local-tx-datasource.jndi-name" \
                   -DConfigXMLLoader.startDepth=0 \
                   -jar $CONFIG_UTILITY print - $XML2 > $OUT
    egrep '.*\.PPPASDSInsert\.(max|min)-pool-size' $OUT | awk '{printf "%s, ", $1}'
    grep  '.*\.PPPASDSInsert\.query-timeout' $OUT | awk '{printf "%s, ", $1}'
    egrep  '.*\.PPPASDSRead\.(max|min)-pool-size' $OUT | awk '{printf "%s, ", $1}'
    grep  '.*\.PPPASDSRead\.query-timeout' $OUT | awk '{printf "%s, ", $1}'
    egrep  '.*\.PPPASDSDupchk\.(max|min)-pool-size' $OUT | awk '{printf "%s, ", $1}'
    grep  '.*\.PPPASDSDupchk\.query-timeout' $OUT | awk '{printf "%s, ", $1}'
    rm -f $XML
    rm -f $XML2
}




unset -f getESSAPIVersion
getESSAPIVersion () {
    $JAVA_BIN/jar -tf /sabre/pppas/JBoss/$INSTANCE/deploy/ppp-ear.ear | \
        grep ice-core | \
        sed -e "s/.*\-\([0-9]\{1,3\}\.[0-9]\{1,3\}[\.0-9]\{0,3\}[\.0-9]\{0,3\}\)\..*/\1/"
}


unset -f getMOMVersion
getMOMVersion () {
    $JAVA_BIN/jar -tf /sabre/pppas/JBoss/$INSTANCE/deploy/ppp-ear.ear | \
        grep sems | \
        sed -e "s/.*[^0-9]\([0-9]\{1,1\}\.[0-9]\{1,1\}\.[0-9]\{1,1\}.*\)\.jar/\1/"
}

unset -f getPubSubTibcoConfig
getPubSubTibcoConfig () {
     #/sabre/pppas/JBoss/PPPAS-CERT1/conf/ICElog4j.properties
    FN=$APPLDIR/conf/ICElog4j.properties
    echo -n "$(sed -e 's/\r//' $FN | grep \^log4j\..\*ProviderURL | awk '{printf "%s ,", $0}')"
    echo -n "$(sed -e 's/\r//' $FN | grep UserName | awk '{printf "%s, ", $0}')"
}
    

unset -f getDBConnectionPoolMax
getDBConnectionPoolMax () {
    XML="/tmp/${SCRIPT%.*}.$$.header.xml"
    XML2="/tmp/${SCRIPT%.*}.$$.oracle-ds.xml"
    echo '<?xml version="1.0" encoding="UTF-8"?>' > $XML
    cat $XML $APPLDIR/deploy/$(echo $APPNAME | tr '[:upper:]' '[:lower:]')-oracle-ds.xml > $XML2
    $JAVA_BIN/java -DConfigXMLLoader.xmlNameTags="name,id,datasources.local-tx-datasource.jndi-name" \
                   -DConfigXMLLoader.startDepth=0 \
                   -jar $CONFIG_UTILITY print - $XML2 | grep  'max-pool-size' | awk '{printf "%s, ", $1}'
}

unset -f getDBOracleTimeout
getDBOracleTimeout () {
    FN=$APPLDIR/conf/jboss-service.xml
    $JAVA_BIN/java -jar $CONFIG_UTILITY print - $FN | grep TransactionTimeout= | awk '{printf "%s, ", $1}'
    $JAVA_BIN/java -jar $CONFIG_UTILITY print - $FN | grep SocketTimeout= | awk '{printf "%s, ", $1}'
}


# find all libs/jars opened by the app process and write out checksum/filename pairs
unset -f get3rdPartyProducts
get3rdPartyProducts () {
    if [ "$PID" != "" ]
    then
        printProcessLibraries $PID 
    else
        echo "No libraries found -- PID not available"
    fi
}

unset -f getAppExeName
getAppExeName () {
    if [ "$PID" != "" ]
    then
        NM=`printProcessExeName $PID`
        if [ "$?" == "0" ] && [ -f "$NM" ]
        then
            echo "${NM##*/}=$(md5sum $NM 2>>$ERRFILE)"
        else 
        # Can't use process name from /proc/pid/exe so just get the one from ps
            echo $(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
        fi
    else
        echo "getAppExeName: PID missing. Cannot determine Process Name"
    fi
}

unset -f getProcessArgs
# Print the args of one process (instance) -- each instance has the same args
getProcessArgs () {
    if [ "$PID" != "" ]
    then
        printProcessArgs $PID
    else
        echo "$APPNAME not running. Cannot determine Java args."
    fi
}


# Setup the application config directory path
#COMPONENTS=(pppas PDCAS)
COMPONENTS=(pppas)
SZ=${#COMPONENTS[@]}
for ((i=0; i<$SZ; i++)); do
    APPNAME=$(echo ${COMPONENTS[$i]} | tr '[:lower:]' '[:upper:]')
    SVCNAME="$APPNAME-$(echo ${ENV} | tr '[:lower:]' '[:upper:]')"
    if [ "$ENV" = "Int" ]
    then
        SVCNAME="${COMPONENTS[$i]}$(echo ${ENV})"
    fi
    APPERROR="None"
    instancecount=1
    PIDS=$(ps -ef | grep "\-c $SVCNAME" | grep -v grep | awk '{print $2}')
    for PID in $PIDS
    do
        INSTANCE="$SVCNAME$instancecount"
        if [ "$ENV" = "Int" ]
        then
            INSTANCE="$SVCNAME"
        fi
        APPLDIR=/sabre/ppp/${COMPONENTS[$i]}/JBoss/$INSTANCE
        if [ "$ENV" = "Int" ] || [ "$ENV" = "Cert" ]
        then
            APPLDIR=/sabre/${COMPONENTS[$i]}/JBoss/$INSTANCE
        fi
        if [ -e "$APPLDIR" ]
        then
            APPLCFGDIR=$APPLDIR/confs
            APPLLOGDIR=/sabre/ppp/logs/$NODE-$INSTANCE
            if [ "$ENV" = "Int" ]
            then
                APPLLOGDIR=$APPLDIR
            elif [ "$ENV" = "Cert" ]
            then
                APPLLOGDIR=/logs/$INSTANCE
            fi
            OUTFILE=`getInstanceOutfile`
            ERRFILE=`getInstanceErrfile`

            # Setup the JAVA_BIN variable from the java command-line if the full path is provided
            JBIN=`getJAVA_BIN $PID`
            RETVAL=$?
            if [ "$JBIN" != "" ] && [ $RETVAL -ne 0 ]
            then
                export JAVA_BIN=$JBIN
            fi
            generateOutput
            publishConfig
        fi
        instancecount=$(( instancecount + 1 ))
    done
done
