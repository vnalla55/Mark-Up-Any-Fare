#!/bin/sh
#### This Template.sh should be called within the application Collection.sh
APPERROR="None"
if [ "${ENV-undefined}" == "undefined" ]
then
    ENV=`echo $NODE | awk '\
    {\
      n=match($1,"[0-9]")
      env=substr($1,n-1,1);
      if (env == "d") print "Dev"; 
      else if (env == "p") print "Prod"; 
      else if (env == "i") print "Int"; 
      else if (env == "c") print "Cert"; 
      else print "Unknown";
    }'`
fi

SESSION=$(ps --no-headers -p $$ | awk '{if ($2 == "?") printf ("%s", "CRON"); else printf ("%s", "TTY");}')
CONFIG_UTILITY=`find $CONFIG_TOOL -name SabreConfigUtil.jar -print | awk '{ if (NR == 1) print $0 }'`

# Setup the JAVA_BIN variable if needed
if [ "${JAVA_BIN}" == "" ] 
then
    if [ "${JAVA_HOME}" != "" ] 
    then
        JAVA_BIN=${JAVA_HOME}/bin
    # see if there is a java found within the PATH
    else
        JAVA_BIN=`which java 2> /dev/null | awk '\
            {\
              n=split($0,array,"/");
              for (i=1;i<=n-1;i++) {
        	    if (i<n-1) 
        	      printf ("%s/",array[i]);
        	    else
        	      printf ("%s",array[i]); 
              }
            }'` 
    fi
fi

APACHE_BIN=/opt/CollabNet_Subversion/bin
TOMCAT_BIN=$CATALINA_HOME/bin
WEBLOGIC_BIN=/opt/weblogic/bin
JBOSS_BIN=/opt/jboss-4.2.2.GA/bin
FREE_CMD=/usr/bin/free
ULIMIT_CMD=ulimit
DF_CMD=/bin/df

# this function returns the outfile use to write instance data
getInstanceOutfile() {
    echo "/tmp/config.$APPNAME.$INSTANCE.$(whoami).out"
}

# this function returns the outfile use to write instance data
getInstanceErrfile() {
    echo "/tmp/config.$APPNAME.$INSTANCE.$(whoami).err"
}

# this function calls the publish jar to send the config items to our config server.
publishConfig() {
    # If INSTANCE is not defined the collection script has not been converted to report the config by instance.
    # In this situation, just use DEFAULT so we'll know the collection script should be updated.
    if [ "${INSTANCE-undefined}" == "undefined" ]
    then
        INSTANCE="DEFAULT"
    fi
    DIMENSIONS="<dimensions complex=\"$NODE\" instance=\"$INSTANCE\" application=\"$APPNAME\" environment=\"$ENV\" script=\"$SCRIPT\" vault=\"$VAULT\"/>"
    echo publishing App:$APPNAME Instance:$INSTANCE configuration items stored in $OUTFILE.
    MSG="Configuration data successfully transferred!"
    if [ -e "$JAVA_BIN" ] && [ -f "$JAVA_BIN/java" ]
    then
        $JAVA_BIN/java -jar $CONFIG_TOOL/SabreConfigUtil.jar publish "$DIMENSIONS" $OUTFILE >> "$ERRFILE" 2>&1
        RETVAL=$?
        if [ $RETVAL -ne 0 ]
        then
            MSG="Config Tool unable to send config data in $OUTFILE! Error details in $ERRFILE"
            LOGMSG="CVGALERT: $MSG"
        fi
    else
        RETVAL=1
        MSG="JAVA not found, cannot publish config data in $OUTFILE."
        LOGMSG=$MSG
    fi
    echo $MSG
    if [ $RETVAL -ne 0 ]
    then
        logger $LOGMSG
    fi
}

# printListItem extracts a value from a list that is defined as below:
#export DEFAULT_JAVA_OPTIONS=-server  -Xmn128m  -Xms256m -Xmx1024m -XX:PermSize=256m -XX:MaxPermSize=512m 
# This is how you woud use printListItem. In this example, the list is inside the setVariables.sh file
# and DEFAULT_JAVA_OPTIONS is the env variable that holds the list.
#getJavaHeapMin () {
#    grep 'DEFAULT_JAVA_OPTIONS' $APPLCFGDIR/setVariables.sh | printListItem "\-Xms" 
#}
printListItem() {
    awk -v item=$1 < /dev/stdin '\
    {\
      n=split($0,array," ");\
      for (i=1;i<=n;i++) {\
	    if (match(array[i],item)) printf ("%s",array[i]);\
      }\
    }'    
}

# Retrieve the Session (cron or tty)
getSession () {
    echo -n "$SESSION"
}

# Retrieve the Java Version
getJavaVersion () {
    if [ "$1" == "" ]
    then
        JAVA="$JAVA_BIN/java"
    else
        JAVA="$1/bin/java"
    fi
	if [ -f $JAVA ]
	then
      $JAVA -version 2>&1 | \
      awk '\
          NR == 1 {printf "%s", substr($3,2,length($3)-2)};
         '
    else
      echo "$JAVA Not Found"
    fi
}

# Retrieve the Java platform size (32 or 64 bit)
getJavaBit () {
    if [ "$1" == "" ]
    then
        JAVA="$JAVA_BIN/java"
    else
        JAVA="$1/bin/java"
    fi
	if [ -f $JAVA ]
	then
      $JAVA -version 2>&1 | \
      awk '\
          NR == 3 {
              JB="32-Bit"; 
              if ($3 == "64-Bit") {
                 JB=$3 
              }; 
              printf "%s", JB;
          }
         '
    else
      echo "$JAVA Not Found"
    fi
}

# Retrieve the application home directory
getAppName () {
    echo "$APPNAME"
}

# Retrieve the application home directory
getAppDir () {
	if [ -e $APPLDIR ]
	then
	  echo "$APPLDIR"
    else
      echo "$APPLDIR Not Found"
    fi
}

# Retrieve the application log directory
getAppLogDir () {
	if [ -e $APPLLOGDIR ]
	then
	  echo "$APPLLOGDIR"
    else
      echo "$APPLLOGDIR Not Found"
    fi
}


# Retrieve the node name
getNodeName () {
    echo   `uname -n | awk -F. '{ print $1 }'`
}

# Retrieve the server's domain name
getNodeDomainName () {
    echo   "`uname -n | awk -F. '\
     { for (i=2; i<=NF; i++)
       {
           domain=sprintf("%s.%s", domain, $(i))
       };
       if (domain == "") {
           domain=".sabre.com";
       };
       print substr(domain,2);
     } '`"
}

# Retrieve the OS name
getOSName () {
    echo   `uname -o`
}

# Retrieve the OS version
getOSVersion () {
    echo   `uname -r`
}

# Retrieve the server memory size (MB)
getOSMem () {
	if [ -f $FREE_CMD ]
	then
      $FREE_CMD -m 2>&1 | \
      awk '\
          {if (match($1,"Mem:")) print $2};\
          '
    else
      echo "$FREE_CMD Not Found"
    fi
}

# Retrieve the OS Swap size (MB)
getOSSwap () {
	if [ -f $FREE_CMD ]
	then
      $FREE_CMD -m 2>&1 | \
      awk '\
          {if (match($1,"Swap:")) print $2};\
          '
    else
      echo "$FREE_CMD Not Found"
    fi
}

# Retrieve the mounted file systems
getFileSystems () {
	if [ -f $DF_CMD ]
	then
      $DF_CMD -h 2>&1 | \
      awk '\
          {if (!match($1,"Filesystem")) printf "%s:%s, ", $1, $2};\
          '
    else
      echo "$DF_CMD Not Found"
    fi
}


# Retriee the OS stack size
getOSStack () {
      echo `$ULIMIT_CMD -s`
}

# Retrieve the number of OS file descriptors
getOSFileDescriptors () {
      echo `$ULIMIT_CMD -n`
}

# Retrieve the OS heap size
getOSHeap () {
      echo `$ULIMIT_CMD -d`
}


# Retrieve the Apache version
getApacheVersion () {
	if [ -f $APACHE_BIN/httpd ]
	then
      $APACHE_BIN/httpd -v 2>&1 | \
      awk 'NR == 1 {print $3};' 
    else
      echo "$APACHE_BIN/httpd Not Found"
    fi
}

# Retrieve the Tomcat version
getTomcatVersion () {
	if [ -f $TOMCAT_BIN/version.sh ]
	then
      sh $TOMCAT_BIN/version.sh 2>&1 | \
      awk '\
          {if (match($1,"Server") && match($2,"number\:")) print $3};\
          '
    else
      echo "$TOMCAT_BIN/run.sh Not Found"
    fi
}

getProcessArgs () {
    echo "Not Implemented"
}

# Retrieve the Oracle version
# THIS HAS BEEN REPLACED BY getOracleConfig which uses java to make the connection to the Oracle DB, below. Keeping it here just for reference.
# This function uses sqlplus but requires ssh to run on a server with sqlplus installed.
#getDBOracleVersion () {
#    echo -e 'select * from v$version where banner like 'Oracle%';\nexit;\n' | \
#    ssh icehld701 'sqlplus eamconfig/eamconfig@//hpblade02-vip.dev.sabre.com:1521/cto11gR2dev' 2>&1 | \
#    awk '$1 == "Oracle" && $2 == "Database" { print $0; }; '
#}

# Retrieve Oracle config items
getOracleConfig () {
#	cd $CONFIG_TOOL/NetBeans.proj/SabreConfigUtil/dist
	java $@ -jar $CONFIG_UTILITY listOracle - 2>&1 | awk '{if (match($1,"DB.Oracle")) print $0; else print "DB.Oracle.Error="$0;}'
}

# Retrieve the WebLogic version
# NEED TO TEST THIS IN AN ENVIRONMENT WITH WebLogic installed
getWebLogicVersion () {
	if [ -f $WEBLOGIC_BIN/weblogic.Admin ]
	then
	$WEBLOGIC_BIN/weblogic.Admin VERSION 2>&1 | awk '{print $0;}'
    else
      echo "$WEBLOGIC_BIN/weblogic.Admin Not Found"
    fi
}

# Retrieve the JBoss version
getJBossVersion () {
	if [ -f $JBOSS_BIN/run.sh ]
	then
	  $JBOSS_BIN/run.sh -V 2>&1 | \
      awk '{if (match($3,"build:")) print $2};'
    else
      echo "$JBOSS_BIN/run.sh Not Found"
    fi
#	  echo 'JBoss 4.2.2.GA (build: SVNTag=JBoss_4_2_2_GA date=200710221139)' | \
}

# Retrieve the Java Version
getScriptName () {
    echo "$SCRIPT"
}

# Retrieve the Java Version
getInstanceName () {
    echo "$INSTANCE"
}


getAppConfigParameters () {
    echo "Not Implemented"
}

getAppThresholds () {
    echo "Not Implemented"
}

getAppTimeouts () {
    echo "Not Implemented"
}

getAppThrottles () {
    echo "Not Implemented"
}

getMOMVersion () {
    echo "Not Implemented"
}
    
getESSAPIVersion () {
    echo "Not Implemented"
}
    
getEIAPIVersion () {
    echo "Not Implemented"
}
    
getICECaching () {
    echo "Not Implemented"
}
    
getPubSubTibcoConfig () {
    echo "Not Implemented"
}
    
getServiceMixVersion () {
    echo "Not Implemented"
}

getCamelVersion () {
    echo "Not Implemented"
}

getPools () {
    echo "Not Implemented"
}

getDBOracleTimeout () {
    echo "Not Implemented"
}

getDBConnectionPoolMax () {
    echo "Not Implemented"
}

get3rdPartyProducts () {
    echo "Not Implemented"
}

getAppError () {
    echo "$APPERROR"
}

getAppExeName () {
    echo "Not Implemented"
}

# Don't default to "Not Implemented" becaues this function generates its own keyname based on the
# exec name and only the app-specific version of this function and determine that.
getAppExeCkSum () {
return 0
}



###
# Here we invoke each function and build the output file which will be passed to the publisher
###
generateOutput () {
cat <<EOFMARK > $OUTFILE
Script.Name=`getScriptName`
App.Name=`getAppName`
App.InstanceName=`getInstanceName`
@App.ExeName=`getAppExeName`
@App.Args=`getProcessArgs`
App.Dir=`getAppDir`
App.LogDir=`getAppLogDir`
@App.Pools=`getPools`
@App.ConfigParameters=`getAppConfigParameters`
@App.Thresholds=`getAppThresholds`
@App.Timeouts=`getAppTimeouts`
@App.Throttles=`getAppThrottles`
@App.3rdPartyProducts=`get3rdPartyProducts`
Node.Name=`getNodeName`
Node.Domain=`getNodeDomainName`
OS.Name=`getOSName`
OS.Version=`getOSVersion`
OS.Mem=`getOSMem`
OS.Swap=`getOSSwap`
@OS.FileSystems=`getFileSystems`
OS.FileDescriptors=`getOSFileDescriptors`
OS.Heap=`getOSHeap`
Apache.Version=`getApacheVersion`
Tomcat.Version=`getTomcatVersion`
JBoss.Version=`getJBossVersion`
WebLogic.Version=`getWebLogicVersion`
ServiceMix.Version=`getServiceMixVersion`
Camel.Version=`getCamelVersion`
MOM.Version=`getMOMVersion`
ESSMAPI.Version=`getESSAPIVersion`
EIAPI.Version=`getEIAPIVersion`
@PubSubTibco.Config=`getPubSubTibcoConfig`
ICECaching=`getICECaching`
@DB.Oracle.Timeout=`getDBOracleTimeout`
@DB.ConnectionPoolMax=`getDBConnectionPoolMax`
Java.Version=`getJavaVersion`
Java.Bit=`getJavaBit`

EOFMARK
}