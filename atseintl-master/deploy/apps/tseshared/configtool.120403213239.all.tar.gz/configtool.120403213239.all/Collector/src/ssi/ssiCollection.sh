#!/bin/bash

# ssiCollection.sh - collect config items for ssi.

echo running $0 $1
CONFIG_TOOL=$(readlink -f `dirname ${0}`/../../..)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)

APPNAME=SSI

# Setup the application config directory path
APPLDIR="/im/ver3.1/lan" # 
APPLCFGDIR=$APPLDIR
APPLLOGDIR=$APPLDIR/logs

source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 


###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###


unset -f getPools
getPools () {
    echo "Not Implemented"
}

unset -f getAppConfigParameters
getAppConfigParameters () {
    XML="/tmp/${SCRIPT%.*/}.$$.header.xml"
    XML2="/tmp/${SCRIPT%.*/}.$$.server.xml"
    CFG="/im/ver3.1/configs/instance."
    if [ "$ENV" == "Int" ]
    then
        CFG=${CFG}Test
    else 
        CFG=${CFG}${ENV}
    fi
    CFG=${CFG}_LAN.xml
    echo '<?xml version="1.0" encoding="UTF-8"?>' > $XML
    cat $XML $CFG > $XML2
    echo -n "$CFG=$($JAVA_BIN/java -jar $CONFIG_UTILITY print - $XML2 | awk '{printf "%s, ", $1}')"
    rm -f $XML
    rm -f $XML2
}

unset -f getAppThresholds
getAppThresholds () {
    echo "Not Implemented"
}

unset -f getAppTimeouts
getAppTimeouts () {
    XML="/tmp/${SCRIPT%.*/}.$$.header.xml"
    XML2="/tmp/${SCRIPT%.*/}.$$.server.xml"
    CFG="/im/ver3.1/configs/instance."
    if [ "$ENV" == "Int" ]
    then
        CFG=${CFG}Test
    else 
        CFG=${CFG}${ENV}
    fi
    CFG=${CFG}_LAN.xml
    echo '<?xml version="1.0" encoding="UTF-8"?>' > $XML
    cat $XML $CFG > $XML2
    echo -n "$($JAVA_BIN/java -jar $CONFIG_UTILITY print - $XML2 | grep -e 'Sell.timeout=' | awk '{printf "%s", $1}')"
    rm -f $XML
    rm -f $XML2
}

unset -f getAppThrottles
getAppThrottles () {
    echo "Not Implemented"
}

# AWAITING KUL TO TELL ME HOW TO DO THIS ONE
getMOMVersion () {
    # Only lookup MOM version on the 1xx nodes (not on the 2xx nodes)
    if [ ${NODE:6:1} == "1" ]
    then
        MOMLIBDIR=/im/mom
      	if [ -e $MOMLIBDIR ]
        then
            echo $(ls -l $MOMLIBDIR | awk '{print $11}' | sed -e "s/.*mom\([0-9]\)\([0-9]\)\([0-9]\)\([0-9][0-9]\).*/\1.\2.\3.\4/")
        else
            echo "Dir $MOMLIBDIR not found"
        fi
    else
        echo "Not Implemented"
    fi
}
    

# find all libs/jars opened by the app process and write out checksum/filename pairs
unset -f get3rdPartyProducts
get3rdPartyProducts () {
    XERCES=/im/xerces/xerces-c-64bits
    EO=/im/router/EO64
	if [ -e $XERCES ]
	then
        echo -n "$(ls -l /im/xerces/xerces-c-64bits | awk '{print $11}'), "
    else
      echo "$XERCES Not Found"
    fi
	if [ -e $EO ]
	then
        echo -n "$(ls -l /im/router/EO64 | awk '{print $11}')"
    else
      echo "$EO Not Found"
    fi
}

unset -f getJavaVersion
getJavaVersion () {
    echo "Not Implemented"
}

unset -f getJavaBit
getJavaBit () {
    echo "Not Implemented"
}

unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getJBossVersion
getJBossVersion () {
    echo "Not Implemented"
}



generateOutput
publishConfig
