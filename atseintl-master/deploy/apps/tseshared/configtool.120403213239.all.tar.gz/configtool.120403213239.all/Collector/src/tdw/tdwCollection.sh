#!/bin/bash

# tdwCollection.sh - collect config items for tdw.

echo running $0 $1
CONFIG_TOOL=$(readlink -f `dirname ${0}`/../../..)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)

APPNAME=ETDW

# Setup the application config directory path
APPLDIR=/tdw/etl/extract/bin/sun # default to CERT/PROD directory
if [ "$ENV" = "Staging" ]
then
    LOG4J="/tdw/etl/extract/bin/sun/conf/Res/INTB/log4j.xml"
else
    LOG4J="/tdw/etl/extract/bin/sun/conf/Res/$(echo $ENV | tr '[:lower:]' '[:upper:]')/log4j.xml"
fi
APPLCFGDIR=$APPLDIR/conf
C=`find $CONFIG_TOOL -name SabreConfigUtil.jar -print | awk '{ if (NR == 1) print $0 }'`
APPLLOGDIR=$APPLDIR/$(java -jar $C getProp log4j:configuration.appender.APP_FILE.File $LOG4J | awk '{match($1, "^.*/"); print substr($1, 1, RLENGTH-1)}')

source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 

###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###

unset -f getMOMVersion
getMOMVersion () {
    find $APPLDIR/lib/ -name *sems*jar -print 2>/dev/null | \
        grep -P '.*sems.*-[\d]+\.[\d]+\.[\d]+\.jar$' | \
        sed -e "s/.*[^0-9]\([0-9]\{1,1\}\.[0-9]\{1,1\}\.[0-9]\{1,1\}\).*/\1/" 
}

unset -f getESSAPIVersion
getESSAPIVersion () {
    find  $APPLDIR/ -name *ice*jar -print | \
        sed -e "s/.*[^0-9]\([0-9]\{1,1\}\.[0-9]\{1,1\}\.[0-9]\{1,1\}\.[0-9]\{1,1\}\).*/\1/" 
}

unset -f getPubSubTibcoConfig
getPubSubTibcoConfig () {
    if [ "$ENV" = "Prod" ]
    then
        PUBSUB=$APPLCFGDIR/Res/PROD/ICElog4j.properties
    elif [ "$ENV" = "Staging" ]
    then
        PUBSUB=$APPLCFGDIR/Res/INTB/ICElog4j.properties
    else    
        PUBSUB=$APPLCFGDIR/Res/CERT/ICElog4j.properties
    fi
    echo -n "$PUBSUB="
    echo -n "log4j.appender.SECURITY.TopicBindingName=$(java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.TopicBindingName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.ProviderURL=$(java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.ProviderURL $PUBSUB), "
    echo -n "log4j.appender.SECURITY.TopicConnectionFactoryBindingName=$(java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.TopicConnectionFactoryBindingName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.InitialContextFactoryName=$(java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.InitialContextFactoryName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.SecurityPrincipalName=$(java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.SecurityPrincipalName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.SecurityCredentials=$(java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.SecurityCredentials $PUBSUB), "
    echo -n "log4j.appender.SECURITY.UserName=$(java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.UserName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.Password=$(java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.Password $PUBSUB)"
#    java -jar $CONFIG_UTILITY print - $PUBSUB | awk '{ if (substr($0,1,1) != "#") printf "%s ", $0; }' | awk '{$1=$1; printf "%s",$0}' OFS=","
}

unset -f getPools
getPools () {
    if [ "$ENV" = "Prod" ]
    then
        FILE=mq-reader${instancecount}.xml
    elif [ "$ENV" = "Staging" ]
    then
        FILE=mq-readerINTB${instancecount}
    else
        FILE=mq-readerCERT${instancecount}.xml
    fi
    if [ "$instancecount" = "1" ]
    then
        C=""
    else
        C="$instancecount"
    fi
    S="momconfig.serviceDefinitions.serviceDefinition.TDW_Res_StgRes$C.serviceOptions.receive.minThreads"
    echo -n $S="$(java -jar $CONFIG_UTILITY getProp $S $APPLCFGDIR/${FILE}), "
    S="momconfig.serviceDefinitions.serviceDefinition.TDW_Res_StgRes$C.serviceOptions.receive.maxThreads"
    echo -n $S="$(java -jar $CONFIG_UTILITY getProp $S $APPLCFGDIR/${FILE}), "
    S="momconfig.infrastructures.infrastructure.Res_infra1.reconnectInterval"
    echo -n $S="$(java -jar $CONFIG_UTILITY getProp $S $APPLCFGDIR/${FILE}), "
    S="momconfig.infrastructures.infrastructure.Res_infra1.reconnectAttempts"
    echo -n $S="$(java -jar $CONFIG_UTILITY getProp $S $APPLCFGDIR/${FILE}), "
    S="momconfig.serviceDefinitions.serviceDefinition.TDW_Res_StgRes$C.serviceOptions.receive.ASF"
    echo -n $S="$(java -jar $CONFIG_UTILITY getProp $S $APPLCFGDIR/${FILE})"
    echo -n "), "
}


unset -f get3rdPartyProducts
get3rdPartyProducts () {
    if [ "$PID" != "" ]
    then
        printProcessLibraries $PID 
    else
        echo "No libraries found -- PID not available"
    fi
}

unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getJBossVersion
getJBossVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getAppExeName
getAppExeName () {
    if [ "$PID" != "" ]
    then
        NM=`printProcessExeName $PID`
        if [ "$?" == "0" ] && [ -f "$NM" ]
        then
            echo "${NM##*/}=$(md5sum $NM 2>>$ERRFILE)"
        else 
        # Can't use process name from /proc/pid/exe so just get the one from ps
            echo $(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
        fi
    else
        echo "getAppExeName: PID missing. Cannot determine Process Name"
    fi
}

unset -f getProcessArgs
# Print the args of one process (instance) -- each instance has the same args
getProcessArgs () {
    if [ "$PID" != "" ]
    then
        printProcessArgs $PID
    else
        echo "$APPNAME not running. Cannot determine Java args."
    fi
}


instancecount=1
if [ "$ENV" = "Cert" ]
then
    PIDS=$(ps -ef | grep MQReader | grep 'Res' | grep 'no=' | grep cert | awk -F' ' '{print $2;}')
elif [ "$ENV" = "Staging" ]
then
    PIDS=$(ps -ef | grep MQReader | grep 'Res' | grep 'intb' | grep 'no=8' | awk -F' ' '{print $2;}')
elif [ "$ENV" = "Prod" ]
then
    PIDS=$(ps -ef | grep MQReader | grep 'Res' | grep 'no=' | awk -F' ' '{print $2;}')
fi
for PID in $PIDS
do
    INSTANCE=$(echo $instancecount | awk '{printf "INSTANCE%03d", $1}')
    OUTFILE=`getInstanceOutfile`
    ERRFILE=`getInstanceErrfile`
    # Setup the JAVA_BIN variable from the java command-line if the full path is provided
    JBIN=`getJAVA_BIN $PID`
    RETVAL=$?
    if [ "$JBIN" != "" ] && [ $RETVAL -ne 0 ]
    then
        export JAVA_BIN=$JBIN
    fi
    generateOutput
    publishConfig
    instancecount=$(( instancecount + 1 ))
done
