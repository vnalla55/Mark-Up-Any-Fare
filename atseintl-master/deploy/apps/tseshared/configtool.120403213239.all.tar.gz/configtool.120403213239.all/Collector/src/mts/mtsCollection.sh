#!/bin/bash

# mtsCollection.sh - collect config items for mts.

echo running $0 $1
CONFIG_TOOL=$(readlink -f `dirname ${0}`/../../..)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)

APPNAME=MTSXfactor

APPDEV_NODE="mmhsld"

# Setup the application config directory path
C=`find $CONFIG_TOOL -name SabreConfigUtil.jar -print | awk '{ if (NR == 1) print $0 }'`
BINDIR=/home/merchant/mm/bin
MTSPROP=$BINDIR/mts.properties
XFACTOR=/home/merchant/mm/xfactor/websvc1
if [ "$ENV" == "Dev" ] ; then
    BINDIR=/merchant/dev1/backend/mm/bin
    XFACTOR=/merchant/dev1/backend/mm/xfactor/websvc
    MTSPROP=$BINDIR/mtsbackend.properties
elif [ "$ENV" == "Cert" ] ; then
    BINDIR=/home/merchant/cert3/backend/mm/bin
    XFACTOR=/home/merchant/cert3/backend/mm/xfactor/websvc
    MTSPROP=$BINDIR/mtsbackend.properties
fi
XPROP=$XFACTOR/xfwebsvc.properties
X1PROP=$XFACTOR/xfwebsvc1.properties

getMtsSetting() {
awk -f $BINDIR/getsetting.awk -f $BINDIR/utils.awk setting="$1" myLog=/tmp/getsetting.$$.log "$2"
}

#OUT=/tmp/config.mts.$$.out
#$BINDIR/mtsbackend.sh -c xfwebsvc1 -a status -v debug | \
#    awk -F' ' '$10 ~ /[a-zA-Z0-9_]=.*/ {n=split($10,array,"=");printf "%s=%s\n", array[1], array[2];}' > $OUT
APPLDIR=$(getMtsSetting xfwebsvc.parentDir $MTSPROP)
APPLCFGDIR=$APPLDIR
APPLLOGDIR=$(getMtsSetting xfwebsvc1.server.log.file $MTSPROP)

export JAVA_HOME=$(getMtsSetting xfwebsvc.java.home $MTSPROP)
export JAVA_BIN="$JAVA_HOME/bin"

source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 



###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###

#$awk -f /merchant/dev1/backend/mm/bin/getsetting.awk -f /merchant/dev1/backend/mm/bin/utils.awk setting=xfwebsvc.app_lib.home myLog=/tmp/getsetting.log /merchant/dev1/backend/mm/bin/mtsbackend.properties

unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getServiceMixVersion
getServiceMixVersion () {
    echo "Not Implemented"
}

# Retrieve the JBoss version
unset -f getJBossVersion
getJBossVersion () {
    getMtsSetting jboss5-1-0.home $MTSPROP | sed -e "s/.*-\([0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\).*/\1/"
}

unset -f getPools
getPools () {
    JBWEB=$XFACTOR/deploy/jbossweb-tomcat50.sar
    if [ "$ENV" == "Dev" ] 
    then
        JBWEB=$XFACTOR/deploy/jbossweb.sar
    fi
    XML="/tmp/${SCRIPT%.*/}.$$.header.xml"
    XML2="/tmp/${SCRIPT%.*/}.$$.server.xml"
    echo '<?xml version="1.0" encoding="UTF-8"?>' > $XML
    cat $XML $JBWEB/server.xml  | \
        awk -F' ' 'BEGIN {i=0;} {if ($1 == "<Connector") printf "%s%d %s\n", $1, ++i, substr($0, index($0,$2)); else print $0;}' > $XML2
    echo -n "Server.Service.jboss.web.Connector1.protocol=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.protocol" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.port=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.port" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.address=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.address" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.maxThreads=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.maxThreads" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.minSpareThreads=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.minSpareThreads" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.maxSpareThreads=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.maxSpareThreads" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.enableLookups=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.enableLookups" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.acceptCount=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.acceptCount" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.connectionTimeout=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.connectionTimeout" $XML2), "
    echo -n "Server.Service.jboss.web.Connector1.disableUploadTimeout=$($JAVA_BIN/java -jar $CONFIG_UTILITY getProp "Server.Service.jboss.web.Connector1.disableUploadTimeout" $XML2), "
    rm -f $XML
    rm -f $XML2
}

unset -f getAppConfigParameters
getAppConfigParameters () {
    echo -n "connect.air.tax.service=$(getMtsSetting connect.air.tax.service $XPROP), "
    echo -n "ssr.mom.connect=$(getMtsSetting ssr.mom.connect $XPROP), "
    echo -n "Providers=$(getMtsSetting Providers $XPROP), "
    echo -n "provider-conf=$(getMtsSetting provider-conf $XPROP), "
    echo -n "SSR.serviceName=$(getMtsSetting SSR.serviceName $X1PROP), "
    echo -n "airTax.usg.url=$(getMtsSetting airTax.usg.url $X1PROP)"
}

unset -f getAppThresholds
getAppThresholds () {
    echo -n "supplier.ssg.monitorSleepTime=$(getMtsSetting supplier.ssg.monitorSleepTime $XPROP), "
    echo -n "supplier.airtax.monitorSleepTime=$(getMtsSetting supplier.airtax.monitorSleepTime $XPROP)"
}

unset -f getAppTimeouts
getAppTimeouts () {
    echo -n "supplier.ssg.refreshConnectionTimeout=$(getMtsSetting supplier.ssg.refreshConnectionTimeout $XPROP), "
    echo -n "supplier.ssg.refreshPoolTimeout=$(getMtsSetting supplier.ssg.refreshPoolTimeout $XPROP), "
    echo -n "supplier.airtax.refreshConnectionTimeout=$(getMtsSetting supplier.airtax.refreshConnectionTimeout $XPROP), "
    echo -n "supplier.airtax.refreshPoolTimeout=$(getMtsSetting supplier.airtax.refreshPoolTimeout $XPROP), "
}

unset -f getESSAPIVersion
getESSAPIVersion () {
    echo "mom.libs.ice=$(getMtsSetting mom.libs.ice $MTSPROP)";
}

unset -f getMOMVersion
getMOMVersion () {
    echo $(getMtsSetting mom.libs.sems $MTSPROP) | sed -e "s/.*[^0-9]\([0-9]\{1,1\}\.[0-9]\{1,1\}\.[0-9]\{1,1\}\).*/\1/"
}

#unset -f get3rdPartyProducts
#get3rdPartyProducts () {
#    echo "xfwebsvc.classpath=$(getMtsSetting xfwebsvc.classpath $MTSPROP)";
#}

unset -f get3rdPartyProducts
get3rdPartyProducts () {
    if [ "$PID" != "" ]
    then
        printProcessLibraries $PID 
    else
        echo "No libraries found -- PID not available"
    fi
}

unset -f getDBOracleTimeout
getDBOracleTimeout () {
    echo -n "database.queryTimeOut=$(getMtsSetting database.queryTimeOut $XPROP), "
    echo -n "database.loginTimeOut=$(getMtsSetting database.loginTimeOut $XPROP), "
    echo -n "database.TCPTimeOut=$(getMtsSetting database.TCPTimeOut $XPROP), "
    echo -n "database.connectionTimeOut=$(getMtsSetting database.connectionTimeOut $XPROP), "
    echo -n "database.readTimeOut=$(getMtsSetting database.readTimeOut $XPROP), "
    echo -n "database.useDataSource=$(getMtsSetting database.useDataSource $XPROP), "
}

unset -f getAppExeName
getAppExeName () {
    if [ "$PID" != "" ]
    then
        NM=`printProcessExeName $PID`
        if [ "$?" == "0" ] && [ -f "$NM" ]
        then
            echo "${NM##*/}=$(md5sum $NM 2>>$ERRFILE)"
        else 
        # Can't use process name from /proc/pid/exe so just get the one from ps
            echo $(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
        fi
    else
        echo "getAppExeName: PID missing. Cannot determine Process Name"
    fi
}

unset -f getProcessArgs
# Print the args of one process (instance) -- each instance has the same args
getProcessArgs () {
    if [ "$PID" != "" ]
    then
        printProcessArgs $PID
    else
        echo "$APPNAME not running. Cannot determine Java args."
    fi
}


#unset -f getJavaArgs
#getJavaArgs () { 
#    echo $(getMtsSetting xfwebsvc1.java.options $MTSPROP) | awk -F' ' '{for(i=1;i<=NF;i++) if ($i!="") printf ("%s ",$i);}'
#}


instancecount=1
PIDS=$($APPLDIR/../bin/status.sh | grep '_XFWEBSVC1' | awk '/pid [0-9]+/{print $14}')
for PID in $PIDS
do
    INSTANCE=$(echo $instancecount | awk '{printf "INSTANCE%03d", $1}')
    OUTFILE=`getInstanceOutfile`
    ERRFILE=`getInstanceErrfile`
    # Setup the JAVA_BIN variable from the java command-line if the full path is provided
    JBIN=`getJAVA_BIN $PID`
    RETVAL=$?
    if [ "$JBIN" != "" ] && [ $RETVAL -ne 0 ]
    then
        export JAVA_BIN=$JBIN
    fi
    generateOutput
    publishConfig
    instancecount=$(( instancecount + 1 ))
done
