#!/bin/bash

# svtCollection.sh - collect config items for svt.

echo running $0 $1
CONFIG_TOOL=$(cd `dirname ${0}`/../../..; pwd)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)

java=$JAVA_HOME/bin/java

#default Application configuration
APPLCFGDIR=/opt/app/svt/artifacts/properties

#default SVT Deploy JAR
APPLDIR=/opt/vto/runtime/jboss/jboss-4.2.2.GA/server/default/deploy

#default JBOSS home
JBOSS_HOME=/opt/vto/runtime/jboss/jboss-4.2.2.GA/bin

#SVT Application WAR
SVT_WAR=svt-web.war

# Get the PID for this app and perform overrides by env if needed
PID=""
if [ "$ENV" = "Cert" ]
then
    OWNER=ita #Override OWNER ID

elif [ "$ENV" = "Staging" ]
then
    OWNER=ita #Override OWNER ID

elif [ "$ENV" = "Prod" ]
then
    OWNER=ita #Override OWNER ID

elif [ "$ENV" = "Dev" ]
then
    # Setup the application config directory path
    #Ovewrrides: Setup the application config directory path
    APPLCFGDIR=/opt/vto/runtime/jboss/jboss-4.2.2.GA/svt
    OWNER=vto #Override OWNER ID
fi


#MOM XML
MOMXML=$APPLCFGDIR/mom.xml

#ORACLE XML
ORACLE_XML=$APPLCFGDIR/oracle_cfg-ds.xml

#PUBSUB Application DIR
PUB_SUB=$APPLCFGDIR/ICE

APPNAME=SVT

if [ "$ENV" = "Staging" ]
then
    LOG4J="/svt/etl/extract/bin/sun/conf/Res/INTB/log4j.xml"
else
    LOG4J="/svt/etl/extract/bin/sun/conf/Res/$(echo $ENV | tr '[:lower:]' '[:upper:]')/log4j.xml"
fi

#TEMP

#C=`find $CONFIG_TOOL -name SabreConfigUtil.jar -print | awk '{ if (NR == 1) print $0 }'`
#timeout=$java -jar $C getProp recvTimeOut.serviceDefinition.serviceDefinitions.momconfig $MOMXML | awk '{match($1, "^.*/"); print substr($1, 1, RLENGTH-1)}')

source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 


###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###

unset -f getMOMVersion
getMOMVersion () {
    jar tvf $APPLDIR/$SVT_WAR|grep sems|grep jar | \
        grep -P '.*sems.*-[\d]+\.[\d]+\.[\d]+\.jar$' | \
        sed -e "s/.*[^0-9]\([0-99]\{1,2\}\.[0-99]\{1,2\}\.[0-99]\{1,2\}\).*/\1/" 
}


unset -f getESSAPIVersion
getESSAPIVersion () {
    jar tvf $APPLDIR/$SVT_WAR|grep ice-core|grep jar | \
        grep -P '.*core*-[\d]+\.[\d]+\.[\d]+\.jar$' | \
        sed -e "s/.*[^0-9]\([0-99]\{1,2\}\.[0-99]\{1,2\}\.[0-99]\{1,2\}\).*/\1/" 
}


unset -f getPubSubTibcoConfig
getPubSubTibcoConfig () {
    if [ "$ENV" = "Prod" ]
    then
        PUBSUB=$PUB_SUB/ICElog4j.properties
    elif [ "$ENV" = "Staging" ]
    then
        PUBSUB=$PUB_SUB/ICElog4j.properties
    else    
        PUBSUB=$PUB_SUB/ICElog4j.properties
    fi

    if [ -e $PUBSUB ] 
    then
    echo -n "$PUBSUB="
    echo -n "log4j.appender.SECURITY.TopicBindingName=$($java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.TopicBindingName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.ProviderURL=$($java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.ProviderURL $PUBSUB), "
    echo -n "log4j.appender.SECURITY.TopicConnectionFactoryBindingName=$($java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.TopicConnectionFactoryBindingName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.InitialContextFactoryName=$($java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.InitialContextFactoryName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.SecurityPrincipalName=$($java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.SecurityPrincipalName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.SecurityCredentials=$($java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.SecurityCredentials $PUBSUB), "
    echo -n "log4j.appender.SECURITY.UserName=$($java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.UserName $PUBSUB), "
    echo -n "log4j.appender.SECURITY.Password=$($java -jar $CONFIG_UTILITY getProp log4j.appender.SECURITY.Password $PUBSUB)"
    fi
}


unset -f getPools
getPools () {

  get_props="momconfig.serviceDefinitions.serviceDefinition.inform.recvTimeOut
momconfig.serviceDefinitions.serviceDefinition.inform.recvTimeOutTimeUnit
momconfig.serviceDefinitions.serviceDefinition.inform.serviceOptions.send.minThreads
momconfig.serviceDefinitions.serviceDefinition.inform.serviceOptions.send.maxThreads
momconfig.serviceDefinitions.serviceDefinition.inform.serviceOptions.receive.minThreads
momconfig.serviceDefinitions.serviceDefinition.inform.serviceOptions.receive.maxThreads"

  for line in $get_props
  do 
   echo  "$line=$($java -jar $CONFIG_UTILITY getProp $line $MOMXML)"
  done

}


unset -f get3rdPartyProducts
get3rdPartyProducts () {
    if [ "$PID" != "" ]
    then
        printProcessLibraries $PID 
    else
        echo "No libraries found -- PID not available"
    fi
}


unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getJBossVersion
getJBossVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getAppExeName
getAppExeName () {
    if [ "$PID" != "" ]
    then
        NM=`printProcessExeName $PID`
        if [ "$?" == "0" ] && [ -f "$NM" ]
        then
            echo "${NM##*/}=$(md5sum $NM 2>>$ERRFILE)"
        else 
        # Can't use process name from /proc/pid/exe so just get the one from ps
            echo $(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
        fi
    else
        echo "getAppExeName: PID missing. Cannot determine Process Name"
    fi
}

unset -f getProcessArgs
# Print the args of one process (instance) -- each instance has the same args
getProcessArgs () {
    if [ "$PID" != "" ]
    then
        printProcessArgs $PID
    else
        echo "$APPNAME not running. Cannot determine Java args."
    fi
}

#PID assignment
PIDS=$(ps -ef | grep jboss | grep $OWNER | grep 'com.sabre.svt' | awk -F' ' '{print $2;}')


for PID in $PIDS
do
 echo $PID 
 ps -p $PID -fx 
 #generateOutput
 #publishConfig
done
