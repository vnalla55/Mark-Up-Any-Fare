#!/bin/bash

# t2asrCollection.sh - collect config items for t2asr.

echo running $0 $1
CONFIG_TOOL=$(readlink -f `dirname ${0}`/../../..)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)

APPNAME=T2-ASR

APPDEV_NODE="tkthld600"

# Setup the application config directory path
APPLDIR=/apps/asr/current # default to CERT/PROD directory
if [ "$NODE" = "$APPDEV_NODE" ] ; then
    APPLDIR=`find /apps/t2/$NODE/dev/asr -maxdepth 1 -name '*' -print | grep -P '.*tkt-asr\.\d\d\d\d\.\d\d.*-dev$' | awk '{ if (NR == 1) print $0 }'`
    if [ "$APPLDIR" = "" ] ; then
        APPLDIR=BaselineNotFound
    fi
fi

APPLCFGDIR=$APPLDIR/etc
APPLLOGDIR=$APPLDIR/logs

source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 

###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###

unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getJBossVersion
getJBossVersion () {
    echo "Not Implemented"
}

unset -f getServiceMixVersion
getServiceMixVersion () {
# change the directory below to something like /apps/tkt/current/etc/
    java -jar $CONFIG_UTILITY getProp esbVersion $APPLCFGDIR/buildInfo.cfg
}

unset -f getMOMVersion
getMOMVersion () {
    find  $APPLDIR/sabre-system -name *sems*jar -print | \
        sed -e "s/.*[^0-9]\([0-9]\{1,1\}\.[0-9]\{1,1\}\.[0-9]\{1,1\}\).*/\1/" 
}

getPoolItem() {
    COMMA=","
    if [ "$3" = "NOCOMMA" ] 
    then
        COMMA=""
    fi
    echo -n "$1=$(java -jar $CONFIG_UTILITY getProp $1 $2)$COMMA "
}

unset -f getPools
getPools () {
    getPoolItem minPoolSize $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg
    getPoolItem maxPoolSize $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg
    getPoolItem inactiveConnectionTimeout $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg
    getPoolItem connectionWaitTimeout $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg
    getPoolItem abandonedConnectionTimeout $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg
    getPoolItem timeToLiveConnectionTimeout $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg
    getPoolItem tcpConnectionTimeout $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg
    getPoolItem readTimeout $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg NOCOMMA
}

unset -f getDBOracleTimeout
getDBOracleTimeout () {
    getPoolItem tcpConnectionTimeout $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg 
    getPoolItem readTimeout $APPLCFGDIR/com.sabre.ticketing.dataaccess.cfg NOCOMMA
}


unset -f get3rdPartyProducts
get3rdPartyProducts () {
    JAR=`find $CONFIG_TOOL/Collector/src/t2asr -name jmx-cmdline-util-1.1-SNAPSHOT.jar -print | awk '{ if (NR == 1) print $0 }'`
    java -jar $JAR $NODE"|5888|com.sabre.ticketing:name=MetricsManager|Bundles.*.*" 2>&1 | \
         awk -F'|' '{printf "%s, ", $NF;}' 

}

unset -f getAppExeName
getAppExeName () {
    if [ "$PID" != "" ]
    then
        NM=`printProcessExeName $PID`
        if [ "$?" == "0" ] && [ -f "$NM" ]
        then
            echo "${NM##*/}=$(md5sum $NM 2>>$ERRFILE)"
        else 
        # Can't use process name from /proc/pid/exe so just get the one from ps
            echo $(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
        fi
    else
        echo "getAppExeName: PID missing. Cannot determine Process Name"
    fi
}

unset -f getProcessArgs
# Print the args of one process (instance) -- each instance has the same args
getProcessArgs () {
    if [ "$PID" != "" ]
    then
        printProcessArgs $PID
    else
        echo "$APPNAME not running. Cannot determine Java args."
    fi
}

if [ -e "$APPLDIR" ]
then
    SMXPID=$APPLDIR/bin/smx_pid.sh
    if [ $NODE = $APPDEV_NODE ] ; then
        SMXPID=`find /apps/t2/$NODE/dev/tkt/tkt* -maxdepth 2 -name 'smx_pid.sh' -print | awk '{ if (NR == 1) print $0 }'`
    fi
    PIDS=$($SMXPID)
    instancecount=1
    for PID in $PIDS
    do
        if [ "$PID" != "NOT_RUNNING" ]
        then
            INSTANCE=$(echo $instancecount | awk '{printf "INSTANCE%03d", $1}')
            OUTFILE=`getInstanceOutfile`
            ERRFILE=`getInstanceErrfile`
            # Setup the JAVA_BIN variable from the java command-line if the full path is provided
            JBIN=`getJAVA_BIN $PID`
            RETVAL=$?
            if [ "$JBIN" != "" ] && [ $RETVAL -ne 0 ]
            then
                export JAVA_BIN=$JBIN
            fi
            generateOutput
            publishConfig
            instancecount=$(( instancecount + 1 ))
        fi
    done
fi
