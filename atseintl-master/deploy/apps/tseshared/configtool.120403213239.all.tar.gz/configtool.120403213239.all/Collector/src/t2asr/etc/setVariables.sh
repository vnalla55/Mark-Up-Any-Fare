export DEFAULT_JAVA_OPTIONS=-server  -Xmn128m  -Xms256m -Xmx1024m -XX:PermSize=256m -XX:MaxPermSize=512m -XX:NewSize=128m -XX:MaxNewSize=512m 
export JAVA_HOME=/usr/java/default
