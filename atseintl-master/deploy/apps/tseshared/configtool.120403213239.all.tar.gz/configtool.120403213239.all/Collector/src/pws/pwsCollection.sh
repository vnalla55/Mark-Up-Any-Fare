#!/bin/bash

# pwsCollection.sh - collect config items for payment.

echo running $0 $1
CONFIG_TOOL=$(readlink -f `dirname ${0}`/../../..)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)

APPNAME=PWS-

APPDEV_NODE="ctovm1631"

source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 

###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###

unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getJBossVersion
getJBossVersion () {
    echo "Not Implemented"
}

unset -f getServiceMixVersion
getServiceMixVersion () {
    if [ "$PWSNAME" = "paymentquery" ]
    then
        BLD=$APPLDIR/etc/buildInfo.cfg
        echo $(grep esbVersion $BLD | awk -F'=' '{printf "%s", $2}')
    else
        echo "Not Implemented"
    fi
}

unset -f getCamelVersion
getCamelVersion () {
    if [ "$PWSNAME" = "paymentquery" ]
    then
        CAMEL=$APPLDIR/system/org/apache/camel/karaf/apache-camel/
        echo $(ls -l $CAMEL | awk '$NF ~ /fuse/ {printf "%s", $NF}')
    else
        echo "Not Implemented"
    fi
}


unset -f getPools
getPools () {
    OUT=/tmp/getpools.$$.txt
    if [ "$PWSNAME" = "paymentquery" ]
    then
        echo -n "$(grep fdc.ds $APPLDIR/etc/fopByStationDc.cfg | sed -e 's/\r//' | awk -F'=' '{printf "%s=%s, ",$1,$2}')"
        echo -n "$(grep idc.ds $APPLDIR/etc/installmentsDc.cfg | sed -e 's/\r//' | awk -F'=' '{printf "%s=%s, ",$1,$2}')"
        FN=$APPLDIR/etc/momconfig.xml
        $JAVA_BIN/java -jar $CONFIG_UTILITY print - $FN > $OUT
        echo -n "$(grep momconfig.serviceDefinitions.serviceDefinition.pymtQuery $OUT | grep send.minThreads), "
        echo -n "$(grep momconfig.serviceDefinitions.serviceDefinition.pymtQuery $OUT | grep send.maxThreads), "
        echo -n "$(grep momconfig.serviceDefinitions.serviceDefinition.pymtQuery $OUT | grep send.timeToLive=), "
        echo -n "$(grep momconfig.serviceDefinitions.serviceDefinition.pymtQuery $OUT | grep send.timeToLiveTimeUnit), "
        echo -n "$(grep momconfig.serviceDefinitions.serviceDefinition.pymtQuery $OUT | grep receive.minThreads), "
        echo -n "$(grep momconfig.serviceDefinitions.serviceDefinition.pymtQuery $OUT | grep receive.maxThreads), "
    else # PWS apps
        echo -n "minPoolSize=$(grep MinConnections $APPLDIR/conf/validate-jdbc-connection.properties | awk -F'=' '{printf "%s", $2}'), "
        echo -n "maxPoolSize=$(grep MaxConnections $APPLDIR/conf/validate-jdbc-connection.properties | awk -F'=' '{printf "%s", $2}'), "
        FN=$APPLDIR/conf/db-context.xml
        $JAVA_BIN/java -jar $CONFIG_UTILITY print - $FN > $OUT
        echo -n "initialPoolSize=$(grep beans.bean.mmpDataSource.property.initialPoolSize.value $OUT), "
        echo -n "idleConnectionTestPeriod=$(grep beans.bean.mmpDataSource.property.idleConnectionTestPeriod.value $OUT), "
        XML="/tmp/${SCRIPT%.*/}.$$.header.xml"
        XML2="/tmp/${SCRIPT%.*/}.$$.server.xml"
        echo '<?xml version="1.0" encoding="UTF-8"?>' > $XML
        FN=$APPLDIR/conf/ehcache.xml
        cat $XML $FN > $XML2
        $JAVA_BIN/java -jar $CONFIG_UTILITY print - $XML2 > $OUT
        echo -n "$(grep ehcache.defaultCache.maxElementsInMemory $OUT), "
        echo -n "$(grep ehcache.defaultCache.eternal $OUT), "
        echo -n "$(grep ehcache.defaultCache.timeToIdleSeconds $OUT), "
        echo -n "$(grep ehcache.defaultCache.timeToLiveSeconds $OUT), "
        echo -n "$(grep ehcache.defaultCache.overflowToDisk $OUT), "
        echo -n "$(grep ehcache.defaultCache.diskPersistent $OUT), "
        echo -n "$(grep ehcache.defaultCache.diskExpiryThreadIntervalSeconds $OUT), "
        FN=$APPLDIR/conf/payment-$(echo $ENV | tr '[:upper:]' '[:lower:]')-momconfig.xml
        $JAVA_BIN/java -jar $CONFIG_UTILITY print - $FN > $OUT
        echo -n "$(grep -e momconfig.serviceDefinitions.serviceDefinition\.$PWSSVCNAME-...-Service $OUT | grep send.minThreads | awk '{printf "%s, ", $1}')"
        echo -n "$(grep -e momconfig.serviceDefinitions.serviceDefinition\.$PWSSVCNAME-...-Service $OUT | grep send.maxThreads | awk '{printf "%s, ", $1}')"
        echo -n "$(grep -e momconfig.serviceDefinitions.serviceDefinition\.$PWSSVCNAME-...-Service $OUT | grep send.timeToLive= | awk '{printf "%s, ", $1}')"
        echo -n "$(grep -e momconfig.serviceDefinitions.serviceDefinition\.$PWSSVCNAME-...-Service $OUT | grep send.timeToLiveTimeUnit | awk '{printf "%s, ", $1}')"
        echo -n "$(grep -e momconfig.serviceDefinitions.serviceDefinition\.$PWSSVCNAME-...-Service $OUT | grep receive.minThreads | awk '{printf "%s, ", $1}')"
        echo -n "$(grep -e momconfig.serviceDefinitions.serviceDefinition\.$PWSSVCNAME-...-Service $OUT | grep receive.maxThreads | awk '{printf "%s, ", $1}')"
        rm -f $OUT
    fi

}


unset -f getESSAPIVersion
getESSAPIVersion () {
if [ "$PWSNAME" = "paymentquery" ]
then
    echo "Not Implemented"
else
    DIR=$APPLDIR/lib
    # example filename: /payment/paymentWS/lib/ice-core-10.2.1.jar
    if [ -e $DIR ] ; then
        find  -L $DIR -name ice-core*jar -print 2>/dev/null | \
            sed -e "s/.*\-\([0-9]\{1,3\}\.[0-9]\{1,3\}[\.0-9]\{0,3\}\)\..*/\1/" | \
            awk '{ if (NR == 1) print $0 }'
    else
        echo -n "$DIR DOES NOT EXIST"
    fi
fi
}

unset -f getEIAPIVersion
getEIAPIVersion () {
if [ "$PWSNAME" = "paymentquery" ]
then
    DIR=$APPLDIR/sabre-system/com/sabre/ei/logging/eiapi-osgi/
    # example filename: /payment/query/current/sabre-system/com/sabre/ei/logging/eiapi-osgi/1.3.2/eiapi-osgi-1.3.2.jar
    if [ -e $DIR ] ; then
        find  -L $DIR -name eiapi*.jar -print 2>/dev/null | \
            sed -e "s/.*\-\([0-9]\{1,3\}\.[0-9]\{1,3\}[\.0-9]\{0,3\}\)\..*/\1/" | \
            awk '{ if (NR == 1) print $0 }'
    else
        echo -n "$DIR DOES NOT EXIST"
    fi
else
    echo "Not Implemented"
fi
}

unset -f getMOMVersion
getMOMVersion () {
if [ "$PWSNAME" = "paymentquery" ]
then
    DIR=$APPLDIR/sabre-system/com/sabre/messaging/sems
else
    DIR=$APPLDIR/lib
fi
find $DIR -name *sems*jar -print | \
    sed -e "s/.*[^0-9]\([0-9]\{1,1\}\.[0-9]\{1,1\}\.[0-9]\{1,1\}\).*/\1/" 
}

unset -f getPubSubTibcoConfig
getPubSubTibcoConfig () {
if [ "$PWSNAME" = "paymentquery" ]
then
    FN=$APPLDIR/conf/eiapi-log4j.pub-sub.properties
else
    FN=$APPLDIR/conf/$(echo $ENV | tr '[:upper:]' '[:lower:]')/ICElog4j.properties
fi
echo -n "$(sed -e 's/\r//' $FN | grep \^log4j\..\*ProviderURL | awk '{printf "%s ,", $0}')"
echo -n "$(sed -e 's/\r//' $FN | grep UserName | awk '{printf "%s, ", $0}')"
}
    

unset -f getDBConnectionPoolMax
getDBConnectionPoolMax () {
if [ "$PWSNAME" = "paymentquery" ]
then
    FN=$APPLDIR/etc/fopByStationDc.cfg
    echo -n "$(grep fdc.ds.maxActiveConnections $FN)"
else
    if [ "$PWSNAME" = "payment" ]
    then
        FN=$APPLDIR/conf/paymentConfig.$(echo $ENV | tr '[:upper:]' '[:lower:]').properties
    else
        FN=$APPLDIR/conf/commonConfig.$(echo $ENV | tr '[:upper:]' '[:lower:]').properties
    fi
    echo -n "$(grep MaxConnections $FN | awk -F'=' '{printf "%s", $2}')"
fi
}


# find all libs/jars opened by the app process and write out checksum/filename pairs
unset -f get3rdPartyProducts
get3rdPartyProducts () {
    if [ "$PID" != "" ]
    then
        printProcessLibraries $PID 
    else
        echo "No libraries found -- PID not available"
    fi
}

unset -f getAppExeName
getAppExeName () {
    if [ "$PID" != "" ]
    then
        NM=`printProcessExeName $PID`
        if [ "$?" == "0" ] && [ -f "$NM" ]
        then
            echo "${NM##*/}=$(md5sum $NM 2>>$ERRFILE)"
        else 
        # Can't use process name from /proc/pid/exe so just get the one from ps
            echo $(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
        fi
    else
        echo "getAppExeName: PID missing. Cannot determine Process Name"
    fi
}

unset -f getProcessArgs
# Print the args of one process (instance) -- each instance has the same args
getProcessArgs () {
    if [ "$PID" != "" ]
    then
        printProcessArgs $PID
    else
        echo "$APPNAME not running. Cannot determine Java args."
    fi
}



# Setup the application config directory path
COMPONENTS=(payment psspayment remotepayment fraudcheck paymentquery)
PWSCOMPS=(PaymentSvc PaymentPSSSvc RemotePaymentSvc FraudCheckSvc)
SZ=${#COMPONENTS[@]}
for ((i=0; i<$SZ; i++)); do
    PWSNAME=`echo ${COMPONENTS[$i]}`
    PWSSVCNAME=`echo ${PWSCOMPS[$i]}`
    APPNAME=`echo PWS-${COMPONENTS[$i]} | tr '[:lower:]' '[:upper:]'`
    if [ "$PWSNAME" = "paymentquery" ]
    then
        APPLDIR=/payment/query/current
    else
        APPLDIR=/payment/paymentWS
        if [ "$ENV" = "Int" ]
        then
            APPLDIR=/payment/paymentWS_INT
        fi
    fi
    APPLCFGDIR=$APPLDIR
    APPLLOGDIR=/payment/logs
    APPERROR="None"
    if [ -e "$APPLDIR" ]
    then
        instancecount=1
        if [ "$PWSNAME" = "paymentquery" ]
        then
            PIDS=$($APPLDIR/bin/qws_pid.sh)
        else
            PIDS=$(cd $APPLDIR/bin; ./status.sh $ENV $PWSNAME 2>> $ERRFILE | awk '{print $7}')
        fi
        for PID in $PIDS
        do
            INSTANCE=$(echo $instancecount | awk '{printf "INSTANCE%03d", $1}')
            OUTFILE=`getInstanceOutfile`
            ERRFILE=`getInstanceErrfile`
            # Setup the JAVA_BIN variable from the java command-line if the full path is provided
            JBIN=`getJAVA_BIN $PID`
            RETVAL=$?
            if [ "$JBIN" != "" ] && [ $RETVAL -ne 0 ]
            then
                export JAVA_BIN=$JBIN
            fi
            generateOutput
            publishConfig
            instancecount=$(( instancecount + 1 ))
        done
    fi
done
