#!/bin/bash

# atseasv2Collection.sh - collect config items for atseasv2.

echo running $0 $1
CONFIG_TOOL=$(readlink -f `dirname ${0}`/../../..)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)

APPNAME=ATSE-ASV2

# Setup the application config directory path
APPLDIR="/opt/atse/asv2" # 
APPLCFGDIR=$APPLDIR/conf
APPLLOGDIR=$APPLDIR
#ADMIN_NODE=$($APPLDIR/showvars.sh COMMON_ADMIN_NODE | awk -F'=' '{print $2}')

source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 


###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###


unset -f getPools
getPools () {
    # Get the threadPoolSizeMin/Max carrier overrides in each xml file in the conf directory
    echo -n $(grep threadPoolSize $APPLCFGDIR/*.xml | 
#              awk '{gsub(/^[\r\n]+|[\r\n]+$/,"");printf "%s, ",$0;}') 
              awk '{printf "%s=%s, ",$1,$3;}') 
    # Get the default threadPoolSizeMin/Max in each xml file in the conf/commons directory
    echo -n $(grep threadPoolSize $APPLCFGDIR/commons/*.xml | \
              sed -e "s/\([a-zA-Z\.]*\)[ ]*<\(threadPoolSize\)\([a-zA-Z]\{3,3\}\)>\([0-9]\{1,3\}\)<.*/\1 \2\3=\4/" | \
              awk '{gsub(/^[\r\n]+|[\r\n]+$/,"");printf "%s, ",$0;}') 
    # Get the default database min/maxIdlePoolSize in each xml file in the conf/commons directory
    echo -n $(grep IdlePoolSize $APPLCFGDIR/commons/*.xml | \
              sed -e "s/\([a-zA-Z\.]*\)[ ]*<\([a-zA-Z]\{3,3\}\)\(IdlePoolSize\)>\([0-9]\{1,3\}\)<.*/\1 \2\3=\4/" | \
              awk '{gsub(/^[\r\n]+|[\r\n]+$/,"");printf "%s, ",$0;}') 
}

unset -f getAppConfigParameters
getAppConfigParameters () {
    echo "Not Implemented"
}

unset -f getAppThresholds
getAppThresholds () {
    echo  $(grep maxConcurrentConnections $APPLCFGDIR/commons/xmlServerConfig.xml | \
            sed -e "s/<\([a-zA-Z]*\)>\([0-9]\{1,3\}\)<.*/\1=\2/")


}

unset -f getAppTimeouts
getAppTimeouts () {
    XML="/tmp/${SCRIPT%.*/}.$$.header.xml"
    echo '<?xml version="1.0" encoding="UTF-8"?>' $( cat $APPLCFGDIR/commons/DCAMethodServerConfig.xml) > $XML
    $JAVA_BIN/java -DConfigXMLLoader.xmlNameTags="name,id,DCAMethodServerConfig.DCASources.DCASource.sourceId" \
                   -DConfigXMLLoader.startDepth=0 -jar $CONFIG_UTILITY print - $XML 2>> $ERRFILE | \
    grep TimeoutMillis | \
    awk '{printf "%s, ", $1}'

    $JAVA_BIN/java -DConfigXMLLoader.xmlNameTags="name,id,DCAMethodServerConfig.DCASources.DCASource.sourceId" \
                   -DConfigXMLLoader.startDepth=0 -jar $CONFIG_UTILITY print - $XML 2>> $ERRFILE | \
    grep carrierCRSTimeouts | \
    awk '{printf "%s, ", $1}'
    rm -f $XML
}

unset -f getAppThrottles
getAppThrottles () {
    echo "$($JAVA_BIN/java -jar $CONFIG_UTILITY print - $APPLCFGDIR/momconfig.xml 2>> $ERRFILE | \
            grep -E '(SKAvailPush|ExpediaService)' | \
            grep Threads | \
            awk '{printf "%s, ", $1}')"
}


# find all libs/jars opened by the app process and write out checksum/filename pairs
unset -f get3rdPartyProducts
get3rdPartyProducts () {
    if [ "$PID" != "" ]
    then
        printProcessLibraries $PID 
    else
        echo "No libraries found -- PID not available"
    fi
}

unset -f getDBOracleTimeout
getDBOracleTimeout () {
    XML="/tmp/$SCRIPT.header.xml"
    echo '<?xml version="1.0" encoding="UTF-8"?>' $(cat $APPLCFGDIR/commons/dataSourcePool.xml) > $XML
    echo "$($JAVA_BIN/java -jar $CONFIG_UTILITY print - $XML 2>> $ERRFILE | \
            grep Timeout | \
            awk '{printf "%s, ", $1}')"
    rm -f $XML
}

unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getJBossVersion
getJBossVersion () {
    echo "Not Implemented"
}

unset -f getAppExeName
getAppExeName () {
    if [ "$PID" != "" ]
    then
        NM=`printProcessExeName $PID`
        if [ "$?" == "0" ] && [ -f "$NM" ]
        then
            echo "${NM##*/}=$(md5sum $NM 2>>$ERRFILE)"
        else 
        # Can't use process name from /proc/pid/exe so just get the one from ps
            echo $(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
        fi
    else
        echo "getAppExeName: PID missing. Cannot determine Process Name"
    fi
}

unset -f getProcessArgs
# Print the args of one process (instance) -- each instance has the same args
getProcessArgs () {
    if [ "$PID" != "" ]
    then
        printProcessArgs $PID
    else
        echo "$APPNAME not running. Cannot determine Java args."
    fi
}





if [ -e "$APPLDIR" ]
then
    ADMIN_NODE=$($APPLDIR/showvars.sh COMMON_ADMIN_NODE | awk -F'=' '{print $2}')
    instancecount=1
    PIDS=$($APPLDIR/appstat.sh | grep 'RUNNING' | awk '{print $7}')
    for PID in $PIDS
    do
        INSTANCE=$(echo $instancecount | awk '{printf "INSTANCE%03d", $1}')
        OUTFILE=`getInstanceOutfile`
        ERRFILE=`getInstanceErrfile`
        # Setup the JAVA_BIN variable from the java command-line if the full path is provided
        JBIN=`getJAVA_BIN $PID`
        RETVAL=$?
        if [ "$JBIN" != "" ] && [ $RETVAL -ne 0 ]
        then
            export JAVA_BIN=$JBIN
        fi
        generateOutput
        publishConfig
        instancecount=$(( instancecount + 1 ))
    done
fi
