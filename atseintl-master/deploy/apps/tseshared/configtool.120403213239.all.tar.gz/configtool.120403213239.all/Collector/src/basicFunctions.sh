#!/bin/sh
# Set of basic functions used by the collector scripts.
# 

SCRIPT=${0##*/}
NODE=`uname -n | awk -F. '{ print $1 }'`
OUTFILE="/tmp/config.$$.out"
ERRFILE="/tmp/config.$$.err"
LSOF_CMD=/usr/sbin/lsof

JAVA_REQUIRED_VER=1.6
getJAVA_BIN () {
    # if there is already a JAVA_BIN setup, see if it has the right version of java.
    # Otherwise we need to find a version of java that will work for our SabreConfigUtil.jar
    if [ "${JAVA_BIN}" != "" ] && [ -e "$JAVA_BIN" ]  
    then
        VER=$($JAVA_BIN/java -version 2>&1 | awk 'NR == 1 {printf "%s", substr($3,2,length($3)-2)};')
        SHORTVER="${VER:0:3}"
    fi
    if [ "${SHORTVER}" != "" ]
    then
        RC=$(echo "$SHORTVER $JAVA_REQUIRED_VER" | awk '{if ($1 >= $2) print "1"}') 
        if [ "$RC" != "" ]
        then
        # This version we already have in JAVA_BIN is good enough
            return 0
        fi
    fi

    # Let's see if the java version used by the application process instance meets our requirements.
    FULL=`printProcessExeName $PID`
    if [ "$?" != "0" ] || [ ! -f "$FULL" ]
    then
        FULL=$(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
    fi
    PGM=${FULL##*/}
    if [  "$PGM" = "java" ]
    then
        if [ "${FULL:0:1}" = "/" ] 
        then
            JAVA_BIN=${FULL:0:${#FULL} - ${#PGM} - 1}
        else
            # The process is Java but it wasn't invoked with a full path to the Java executable.
            # So, we need to see if java is in the java process' PATH so we should set our
            # PATH to the same value as the java process' and then search for java
            P=$(strings /proc/$PID/environ 2>> $ERRFILE | grep '^PATH' | awk -F'=' '{print $2}')
            if [ "$P" != "" ]
            then
                SAVEPATH=$PATH
                export PATH=$P
                JBIN=`which java 2>> $ERRFILE | awk '\
                {\
                  n=split($0,array,"/");
                  for (i=1;i<=n-1;i++) {
            	    if (i<n-1) 
            	      printf ("%s/",array[i]);
            	    else
            	      printf ("%s",array[i]); 
                  }
                }'` 
                if [ "$JBIN" = "" ]
                then
                    JAVA_BIN=$JBIN
                fi 
                export PATH=$SAVEPATH #restore path
            else
                return 0
            fi
        fi
        echo $JAVA_BIN
        return 1
    fi
    return 0
}


# Right now we only need to support Vault or Non-Vault.
getVault () {
    V=$(echo $1 | tr '[:upper:]' '[:lower:]')
    if [ "$V" = "Y" ] || [ "$V" = "YES" ]
    then
        echo "Y"
    else
        echo "N"
    fi
}
 

getEnv () {
    # make first character uppercase and the rest lower
    ENVO=$(echo "${2:0:1}" | tr '[:lower:]' '[:upper:]')$(echo "${2:1}" | tr '[:upper:]' '[:lower:]')
    echo $(echo $1 | \
    awk "BEGIN { override = \"${ENVO}\"} \
    {
      n=match(\$1,\"[0-9]\")
      if (n == 0) n = length(\$1)+1;
      env=substr(\$1,n-1,1);
      if (override == \"Dev\") print override;
      else if (override == \"Int\") print override;
      else if (override == \"Cert\") print override;
      else if (override == \"Staging\") print override;
      else if (override == \"Prod\") print override;
      else if (env == \"d\") print \"Dev\";
      else if (env == \"p\") print \"Prod\";
      else if (env == \"i\") print \"Int\";
      else if (env == \"c\") print \"Cert\";
      else print \"Unknown\";
    }")
}

printProcessExeName () {
    local RC=0
    if [ "$1" != "" ]
    then
        ls -l /proc/$PID/exe 2>>$ERRFILE | awk '{print $11}'
        P=(${PIPESTATUS[*]})
        if [ "${P[0]}" != "0" ]
        then
            RC=${P[0]}
        fi
    else
        RC=1
    fi
    return $RC
}

# print the process args. Requires the PID in $1
printProcessArgs () {
    local RC=0
    if [ "$1" != "" ] ; then
        echo $(cat /proc/$PID/cmdline | awk -F'\000' '{for(i=2;i<=NF;i++) if ($i!="") printf ("%s ",$i);}')
    else
        echo "printProcessArgs: PID missing. Cannot collect Java args."
        RC=1
    fi
    return $RC
}

# print the process libraries/checksums for libraries the process has open. Requires the PID in $1
printProcessLibraries () {
    local RC=0
    if [ "$1" != "" ]
    then
        $LSOF_CMD -p $1 | 
            awk '\
            {
                if ($NF == "denied)")
                    printf "%s %s, ", "denied", $(NF-3);
                else if ($NF != "NAME" && $NF != "" && $NF != "/") {
                    i=index($NF,".");
                    if (i>0) {
                        ext=substr($NF,i);
                        if (ext == ".so" || ext == ".jar") {
                            system("md5sum " $NF);
                            printf ", ";
                        }
                    }
                }
            }'
    else 
        echo "printProcessLibraries: PID missing. Cannot collect process libraries."
        RC=1
    fi
    return $RC
}