#!/bin/bash

# atsepricingv2Collection.sh - collect config items for atsepricingv2.

echo running $0 $1
CONFIG_TOOL=$(readlink -f `dirname ${0}`/../../..)
source "$CONFIG_TOOL/Collector/src/basicFunctions.sh" 
ENV_OVERRIDE="$1"
VAULT=$(getVault "$2")
ENV=$(getEnv $NODE $ENV_OVERRIDE)

APPNAME=ATSE

# Setup the application config directory path

COMPONENTS=(faredisplay historical pricingv2 shopping shoppingesv shoppinghist shoppingis tax)
if [ "${JAVA_HOME}" == "" ] 
then
    JAVA_BIN=/opt/atseintl/3rdParty/jre1.6.0_21/bin
fi

source "$CONFIG_TOOL/Collector/src/commonCollection.sh" 


###
# Setup the application specific functions below. 
# Remember to unset the function first because it was already declared in Template.sh
###


unset -f getPools
getPools () {
    echo "Not Implemented"
}

unset -f getAppConfigParameters
getAppConfigParameters () {
    echo "Not Implemented"
}

unset -f getAppThresholds
getAppThresholds () {
    if [ "$JAVA_BIN" != "" ]
    then
        $JAVA_BIN/java -jar $CONFIG_UTILITY getProp TRX_THRESHOLD $APPLCFGDIR/tseserver.acms.cfg
    else
        echo "No AppThresholds found -- Java not available"
    fi
}

unset -f getAppTimeouts
getAppTimeouts () {
    if [ "$JAVA_BIN" != "" ]
    then
        $JAVA_BIN/java -jar $CONFIG_UTILITY getProp TRX_TIMEOUT $APPLCFGDIR/tseserver.acms.cfg
    else
        echo "No AppTimeouts found -- Java not available"
    fi
}

unset -f getAppThrottles
getAppThrottles () {
    echo "Not Implemented"
}

# find all libs/jars opened by the app process and write out checksum/filename pairs
unset -f get3rdPartyProducts
get3rdPartyProducts () {
    if [ "$PID" != "" ]
    then
        printProcessLibraries $PID 
    else
        echo "No libraries found -- PID not available"
    fi
}

unset -f getDBOracleTimeout
getDBOracleTimeout () {
SQLNET=/opt/db/ini/sqlnet.ora
    echo -n "TCP.CONNECT_TIMEOUT=$(grep TCP.CONNECT_TIMEOUT $SQLNET), "
    echo -n "SQLNET.OUTBOUND_CONNECT_TIMEOUT=$(grep SQLNET.OUTBOUND_CONNECT_TIMEOUT $SQLNET)"
}


unset -f getJavaVersion
getJavaVersion () {
    echo "Not Implemented"
}

unset -f getJavaBit
getJavaBit () {
    echo "Not Implemented"
}

unset -f getApacheVersion
getApacheVersion () {
    echo "Not Implemented"
}

unset -f getTomcatVersion
getTomcatVersion () {
    echo "Not Implemented"
}

unset -f getWebLogicVersion
getWebLogicVersion () {
    echo "Not Implemented"
}

unset -f getJBossVersion
getJBossVersion () {
    echo "Not Implemented"
}

unset -f getAppExeName
getAppExeName () {
    if [ "$PID" != "" ]
    then
        NM=`printProcessExeName $PID`
        if [ "$?" == "0" ] && [ -f "$NM" ]
        then
            echo "${NM##*/}=$(md5sum $NM 2>>$ERRFILE)"
        else 
        # Can't use process name from /proc/pid/exe so just get the one from ps
            echo $(ps --no-headers -fp "$PID" 2>> $ERRFILE | awk '{print $8}')
        fi
    else
        echo "getAppExeName: PID missing. Cannot determine Process Name"
    fi
}

unset -f getProcessArgs
# Print the args of one process (instance) -- each instance has the same args
getProcessArgs () {
    if [ "$PID" != "" ]
    then
        printProcessArgs $PID
    else
        echo "$APPNAME not running. Cannot determine Java args."
    fi
}



SZ=${#COMPONENTS[@]}
for ((i=0; i<$SZ; i++)); do
    ATSENAME=`echo ${COMPONENTS[$i]}`
    APPNAME=`echo ATSE-${COMPONENTS[$i]} | tr '[:lower:]' '[:upper:]'`
    APPLDIR="/opt/atseintl/$ATSENAME" # 
    APPLCFGDIR=$APPLDIR
    APPLLOGDIR=$APPLDIR
    APPERROR="None"
    if [ -e "$APPLDIR" ]
    then
        ADMIN_NODE=$($APPLDIR/showvars.sh COMMON_ADMIN_NODE | awk -F'=' '{print $2}')
        instancecount=1
        PIDS=$($APPLDIR/appstat.sh | grep 'RUNNING' | awk '{print $7}')
        for PID in $PIDS
        do
            INSTANCE=$(echo $instancecount | awk '{printf "INSTANCE%03d", $1}')
            OUTFILE=`getInstanceOutfile`
            ERRFILE=`getInstanceErrfile`
            # Setup the JAVA_BIN variable from the java command-line if the full path is provided
            JBIN=`getJAVA_BIN $PID`
            RETVAL=$?
            if [ "$JBIN" != "" ] && [ $RETVAL -ne 0 ]
            then
                export JAVA_BIN=$JBIN
            fi
            generateOutput
            publishConfig
            instancecount=$(( instancecount + 1 ))
        done
    fi
done
